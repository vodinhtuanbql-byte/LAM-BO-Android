package vn.lambo.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class BrokerActivity extends Activity {
    public static final String EXTRA_URL = "broker_url";
    public static final String EXTRA_NAME = "broker_name";
    private FrameLayout root;
    private WebView webView;
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final Runnable clockReader = new Runnable(){ public void run(){ readBrokerClock(); clockHandler.postDelayed(this,250); } };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        String url = getIntent().getStringExtra(EXTRA_URL);
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) {
            Toast.makeText(this, "Địa chỉ sàn không hợp lệ", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        setTitle(getIntent().getStringExtra(EXTRA_NAME));
        CookieManager.getInstance().setAcceptCookie(true);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.addJavascriptInterface(new TimerBridge(), "BrokerClock");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) Toast.makeText(BrokerActivity.this,
                    "Trang sàn không tải được. Kiểm tra mạng hoặc thử Mở ngoài.", Toast.LENGTH_LONG).show();
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    Toast.makeText(BrokerActivity.this, "Website trả về lỗi HTTP " + response.getStatusCode(), Toast.LENGTH_LONG).show();
                }
            }
            @Override public void onPageFinished(WebView view, String loadedUrl) {
                CookieManager.getInstance().flush();
                clockHandler.removeCallbacks(clockReader); clockHandler.post(clockReader);
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webView.loadUrl(url);
    }


    public final class TimerBridge {
        @JavascriptInterface public void update(int seconds) {
            if(seconds < 0 || seconds > 120) return;
            getSharedPreferences("broker_clock", MODE_PRIVATE).edit()
                .putInt("seconds", seconds).putLong("at", System.currentTimeMillis()).apply();
        }
    }
    private void readBrokerClock() {
        if(webView == null || isFinishing()) return;
        String js = "(function(){try{var es=[...document.querySelectorAll('body *')];" +
            "var cand=[];for(var e of es){if(!e||!e.getClientRects().length)continue;" +
            "var s=(e.innerText||e.textContent||'').trim();if(!s||s.length>8)continue;" +
            "var m=s.match(/^(\\d{1,2})s$/i);if(m){cand.push(+m[1]);continue;}" +
            "m=s.match(/^(\\d{1,2}):(\\d{2})$/);if(m){cand.push((+m[1])*60+(+m[2]));}}" +
            "if(cand.length){var v=cand.find(x=>x<=60);if(v!==undefined)BrokerClock.update(v);}" +
            "}catch(e){}})();";
        webView.evaluateJavascript(js, null);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause() {
        clockHandler.removeCallbacks(clockReader);
        if (webView != null) webView.onPause();
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override protected void onDestroy() {
        clockHandler.removeCallbacks(clockReader);
        if (webView != null) {
            webView.stopLoading();
            root.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
