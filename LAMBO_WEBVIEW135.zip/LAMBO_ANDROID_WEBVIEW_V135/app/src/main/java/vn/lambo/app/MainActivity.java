package vn.lambo.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private WebView appView;
    private static final String[] BROKER_URLS = {
        "https://luxwin3.net/",
        "https://coltra1.net/",
        "https://fiaura1.net/"
    };
    private static final String[] BROKER_NAMES = {"LUXWIN", "COLTRA1", "FIAURA1"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        CookieManager.getInstance().setAcceptCookie(true);
        createAppView();
    }

    private void createAppView() {
        if (isFinishing() || isDestroyed() || appView != null) return;
        WebView view = new WebView(this);
        appView = view;
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        view.setWebChromeClient(new WebChromeClient());
        view.setWebViewClient(new WebViewClient());
        view.addJavascriptInterface(new Bridge(), "Android");
        setContentView(view);
        view.loadUrl("file:///android_asset/index.html");
    }

    // Chỉ giữ một WebView hoạt động tại một thời điểm: giải phóng WebView giao diện
    // trước khi mở WebView của sàn để giảm áp lực RAM trên điện thoại.
    private void openBroker(final int index) {
        if (index < 0 || index >= BROKER_URLS.length || isFinishing() || isDestroyed()) return;
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            Intent intent = new Intent(MainActivity.this, BrokerActivity.class);
            intent.putExtra(BrokerActivity.EXTRA_URL, BROKER_URLS[index]);
            intent.putExtra(BrokerActivity.EXTRA_NAME, BROKER_NAMES[index]);

            WebView old = appView;
            appView = null;
            setContentView(new FrameLayout(MainActivity.this));
            if (old != null) {
                try { old.stopLoading(); } catch (Exception ignored) { }
                try { old.removeJavascriptInterface("Android"); } catch (Exception ignored) { }
                try { old.setWebViewClient(null); } catch (Exception ignored) { }
                try { old.setWebChromeClient(null); } catch (Exception ignored) { }
                try { old.destroy(); } catch (Exception ignored) { }
            }
            startActivity(intent);
        });
    }

    private class Bridge {
        @JavascriptInterface public void openBroker(final int index) {
            openBroker(index);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        // Khi quay về từ BrokerActivity, tạo lại giao diện chính.
        if (appView == null) createAppView();
    }

    @Override public void onBackPressed() {
        if (appView != null && appView.canGoBack()) appView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override protected void onDestroy() {
        if (appView != null) {
            try { appView.stopLoading(); } catch (Exception ignored) { }
            try { appView.removeJavascriptInterface("Android"); } catch (Exception ignored) { }
            appView.destroy();
            appView = null;
        }
        super.onDestroy();
    }
}
