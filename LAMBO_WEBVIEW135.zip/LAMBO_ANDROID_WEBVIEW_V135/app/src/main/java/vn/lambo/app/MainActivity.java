package vn.lambo.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String TAG = "LAMBO";
    private static final String[] URLS = {
        "https://luxwin3.net/", "https://coltra1.net/", "https://fiaura1.net/"
    };
    private static final String[] NAMES = {"LUXWIN", "COLTRA1", "FIAURA1"};
    private FrameLayout root;
    private WebView appView;
    private final WebView[] brokerViews = new WebView[3];
    private final FrameLayout.LayoutParams[] brokerLayouts = new FrameLayout.LayoutParams[3];
    private final boolean[] loaded = new boolean[3];
    private final boolean[] failed = new boolean[3];
    private float density;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        density = getResources().getDisplayMetrics().density;
        CookieManager.getInstance().setAcceptCookie(true);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5, 12, 25));
        setContentView(root);
        createAppView();
        // Create broker WebViews only when the user opens a broker.
        // Keeping four WebViews alive at cold start can exhaust renderer memory on older phones.
    }

    private void createAppView() {
        appView = new WebView(this);
        WebSettings s = appView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        appView.setBackgroundColor(Color.rgb(5, 10, 23));
        appView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(android.webkit.ConsoleMessage message) {
                Log.e(TAG, "APP JS " + message.message() + " at " + message.sourceId() + ":" + message.lineNumber());
                return true;
            }
        });
        appView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                Log.i(TAG, "APP loading: " + url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                Log.i(TAG, "APP loaded: " + url);
                view.evaluateJavascript("document.documentElement.style.background='#050a17';document.body.style.background='#050a17';", null);
                view.postDelayed(MainActivity.this::updateAllBounds, 250);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    String msg = "Không mở được giao diện LAM BO: " + error.getErrorCode() + " - " + error.getDescription();
                    Log.e(TAG, msg + " URL=" + request.getUrl());
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                    view.post(() -> {
                        if (view == appView) {
                            view.loadDataWithBaseURL(null,
                                "<html><meta name='viewport' content='width=device-width,initial-scale=1'><body style='background:#101827;color:white;font:16px sans-serif;padding:24px'><h2>LAM BO chưa tải được giao diện</h2><p>" +
                                msg.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;") +
                                "</p><p>Hãy gửi ảnh màn hình này cho bộ phận hỗ trợ.</p></body></html>",
                                "text/html","UTF-8",null);
                        }
                    });
                }
            }
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                Log.e(TAG, "APP WebView renderer stopped; crash=" + detail.didCrash());
                // A dead WebView cannot be reused. Remove it and recreate the local UI.
                if (view == appView) {
                    try { root.removeView(view); } catch (Exception ignored) {}
                    try { view.removeJavascriptInterface("Android"); view.destroy(); } catch (Exception ignored) {}
                    appView = null;
                    root.postDelayed(() -> {
                        if (!isFinishing() && !isDestroyed() && appView == null) {
                            Log.i(TAG, "Recreating main LAM BO WebView after renderer exit");
                            createAppView();
                            root.postDelayed(MainActivity.this::updateAllBounds, 900);
                        }
                    }, 500);
                }
                Toast.makeText(MainActivity.this, "LAM BO đang khôi phục giao diện WebView…", Toast.LENGTH_LONG).show();
                return true;
            }
        });
        appView.addJavascriptInterface(new Bridge(), "Android");
        root.addView(appView, 0, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        appView.loadUrl("file:///android_asset/index.html");
    }

    // Three independent WebViews are created lazily and stay in their existing broker-card slots.
    private void createBrokerViews() {
        for (int i = 0; i < 3; i++) createBrokerView(i);
    }

    private void createBrokerView(final int index) {
        WebView w = new WebView(this);
        brokerViews[index] = w;
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        String ua = s.getUserAgentString();
        if (ua != null) s.setUserAgentString(ua.replace("; wv", ""));
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean isDialog,
                                                     boolean isUserGesture, android.os.Message resultMsg) {
                WebView popup = new WebView(MainActivity.this);
                WebSettings ps = popup.getSettings();
                ps.setJavaScriptEnabled(true);
                ps.setDomStorageEnabled(true);
                ps.setJavaScriptCanOpenWindowsAutomatically(true);
                ps.setSupportMultipleWindows(true);
                CookieManager.getInstance().setAcceptThirdPartyCookies(popup, true);
                popup.setWebChromeClient(new WebChromeClient());
                popup.setWebViewClient(new WebViewClient() {
                    @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                        String scheme = req.getUrl().getScheme();
                        return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
                    }
                });
                android.widget.PopupWindow window = new android.widget.PopupWindow(
                    popup, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, true);
                window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.WHITE));
                window.setOnDismissListener(() -> { popup.stopLoading(); popup.destroy(); });
                window.showAtLocation(root, android.view.Gravity.CENTER, 0, 0);
                ((WebView.WebViewTransport) resultMsg.obj).setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }
        });
        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                loaded[index] = false;
                failed[index] = false;
                Log.i(TAG, NAMES[index] + " loading: " + url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                loaded[index] = true;
                failed[index] = false;
                Log.i(TAG, NAMES[index] + " loaded: " + url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    failed[index] = true;
                    String detail = NAMES[index] + " lỗi WebView " + error.getErrorCode() + ": " + error.getDescription();
                    Log.e(TAG, detail + " URL=" + request.getUrl());
                    Toast.makeText(MainActivity.this, detail, Toast.LENGTH_LONG).show();
                }
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                                       WebResourceResponse response) {
                if (request.isForMainFrame()) {
                    failed[index] = true;
                    String detail = NAMES[index] + " trả HTTP " + response.getStatusCode();
                    Log.e(TAG, detail + " URL=" + request.getUrl());
                    Toast.makeText(MainActivity.this, detail, Toast.LENGTH_LONG).show();
                }
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                failed[index] = true;
                String detail = NAMES[index] + " lỗi chứng chỉ HTTPS: " + error;
                Log.e(TAG, detail);
                Toast.makeText(MainActivity.this, detail, Toast.LENGTH_LONG).show();
            }
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                Log.e(TAG, NAMES[index] + " renderer gone");
                if (root != null) root.removeView(view);
                view.destroy();
                brokerViews[index] = null;
                loaded[index] = false;
                failed[index] = true;
                Toast.makeText(MainActivity.this, NAMES[index] + ": WebView bị dừng; mở lại ứng dụng để thử", Toast.LENGTH_LONG).show();
                return true;
            }
        });
        w.setBackgroundColor(Color.rgb(5, 11, 25));
        brokerLayouts[index] = new FrameLayout.LayoutParams(1, 1);
        root.addView(w, brokerLayouts[index]);
        w.setVisibility(View.INVISIBLE);
        // Stagger startup to reduce memory and network spikes on lower-memory phones.
        w.postDelayed(() -> {
            if (!isFinishing() && !isDestroyed() && brokerViews[index] == w) {
                Log.i(TAG, "Starting broker load " + NAMES[index] + " " + URLS[index]);
                w.loadUrl(URLS[index]);
            }
        }, index * 3500L);
    }

    private void updateBrokerBounds(int index, float x, float y, float width, float height) {
        if (index < 0 || index > 2 || brokerViews[index] == null || brokerLayouts[index] == null) return;
        int left = Math.round(x * density);
        int top = Math.round(y * density);
        int w = Math.max(1, Math.round(width * density));
        int h = Math.max(1, Math.round(height * density));
        FrameLayout.LayoutParams p = brokerLayouts[index];
        p.width = w;
        p.height = h;
        p.leftMargin = left;
        p.topMargin = top;
        brokerViews[index].setLayoutParams(p);
        brokerViews[index].setVisibility(width > 0 && height > 0 ? View.VISIBLE : View.INVISIBLE);
    }

    private void openBroker(int index) {
        if (index < 0 || index > 2) return;
        runOnUiThread(() -> {
            if (brokerViews[index] == null) createBrokerView(index);
            Toast.makeText(this, "LAM BO: " + NAMES[index] + " đang chạy trong khung riêng", Toast.LENGTH_SHORT).show();
            if (failed[index] && brokerViews[index] != null) {
                failed[index] = false;
                brokerViews[index].reload();
            }
            updateAllBounds();
        });
    }

    private void updateAllBounds() {
        if (appView == null) return;
        appView.evaluateJavascript(
            "(function(){for(var i=0;i<3;i++){var e=document.getElementById('mini'+i);if(e){var r=e.getBoundingClientRect();" +
            "if(window.Android&&Android.updateBrokerBounds)Android.updateBrokerBounds(i,r.left,r.top,r.width,r.height);}}})()", null);
    }

    private void closeBroker(int index) {
        if (index < 0 || index > 2 || brokerViews[index] == null) return;
        runOnUiThread(() -> brokerViews[index].setVisibility(View.INVISIBLE));
    }

    public final class Bridge {
        @JavascriptInterface public void openBroker(final int index) { openBroker(index); }
        @JavascriptInterface public void closeBroker(final int index) { closeBroker(index); }
        @JavascriptInterface public void updateBrokerBounds(final int index, final float x, final float y,
                                                              final float width, final float height) {
            runOnUiThread(() -> updateBrokerBounds(index, x, y, width, height));
        }
    }

    @Override public void onBackPressed() {
        // Keep the three platform sessions alive; Back first navigates the focused web content if possible.
        for (int i = 2; i >= 0; i--) {
            WebView w = brokerViews[i];
            if (w != null && w.hasFocus() && w.canGoBack()) { w.goBack(); return; }
        }
        super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
        if (appView != null) appView.onPause();
        for (WebView w : brokerViews) if (w != null) w.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (appView != null) appView.onResume();
        for (WebView w : brokerViews) if (w != null) w.onResume();
        if (appView != null) appView.postDelayed(this::updateAllBounds, 700);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && appView != null) appView.postDelayed(this::updateAllBounds, 180);
    }

    @Override protected void onDestroy() {
        for (int i = 0; i < 3; i++) {
            WebView w = brokerViews[i];
            if (w != null) {
                w.stopLoading();
                root.removeView(w);
                w.destroy();
                brokerViews[i] = null;
            }
        }
        if (appView != null) {
            appView.stopLoading();
            appView.removeJavascriptInterface("Android");
            root.removeView(appView);
            appView.destroy();
            appView = null;
        }
        super.onDestroy();
    }
}
