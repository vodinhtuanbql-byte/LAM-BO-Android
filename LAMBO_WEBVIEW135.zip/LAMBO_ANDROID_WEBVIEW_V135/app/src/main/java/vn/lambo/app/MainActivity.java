package vn.lambo.app;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String TAG = "LAMBO";
    private static final String[] URLS = {"https://luxwin3.net/", "https://coltra1.net/", "https://fiaura1.net/"};
    private static final String[] NAMES = {"LUXWIN", "COLTRA1", "FIAURA1"};
    private FrameLayout root;
    private WebView appView;
    private final WebView[] brokerViews = new WebView[3];
    private final int[][] lastBounds = new int[3][4];

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        CookieManager.getInstance().setAcceptCookie(true);
        root = new FrameLayout(this);
        setContentView(root);
        createAppView();
        createBrokerViews();
    }

    private void createAppView() {
        appView = new WebView(this);
        WebSettings s = appView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setLoadsImagesAutomatically(true);
        appView.setWebChromeClient(new WebChromeClient());
        appView.setWebViewClient(new WebViewClient());
        appView.addJavascriptInterface(new Bridge(), "Android");
        root.addView(appView, new FrameLayout.LayoutParams(-1, -1));
        appView.loadUrl("file:///android_asset/index.html");
    }

    private void createBrokerViews() {
        for (int i = 0; i < URLS.length; i++) {
            final int index = i;
            WebView w = new WebView(this);
            brokerViews[i] = w;
            WebSettings s = w.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setLoadsImagesAutomatically(true);
            s.setSupportMultipleWindows(false);
            s.setJavaScriptCanOpenWindowsAutomatically(false);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
            w.setWebChromeClient(new WebChromeClient());
            w.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                    String scheme = request.getUrl().getScheme();
                    return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
                }
                @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                    if (request.isForMainFrame()) Log.e(TAG, NAMES[index] + " load error: " + error.getDescription());
                }
                @Override public void onReceivedHttpError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceResponse response) {
                    if (request.isForMainFrame()) Log.e(TAG, NAMES[index] + " HTTP " + response.getStatusCode());
                }
                @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                    Log.e(TAG, NAMES[index] + " renderer gone");
                    view.setVisibility(View.INVISIBLE);
                    return true;
                }
            });
            w.setVisibility(View.INVISIBLE);
            root.addView(w, new FrameLayout.LayoutParams(1, 1));
            w.loadUrl(URLS[i]);
        }
    }

    private void setBrokerBounds(int index, float x, float y, float width, float height) {
        if (index < 0 || index > 2 || brokerViews[index] == null || root == null) return;
        final float density = getResources().getDisplayMetrics().density;
        final int left = Math.max(0, Math.round(x * density));
        final int top = Math.max(0, Math.round(y * density));
        final int widthPx = Math.max(1, Math.round(width * density));
        final int heightPx = Math.max(1, Math.round(height * density));
        runOnUiThread(() -> {
            WebView view = brokerViews[index];
            if (view == null || isFinishing() || isDestroyed()) return;
            int[] b = lastBounds[index];
            if (b[0] == left && b[1] == top && b[2] == widthPx && b[3] == heightPx) return;
            b[0] = left; b[1] = top; b[2] = widthPx; b[3] = heightPx;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(widthPx, heightPx);
            lp.leftMargin = left; lp.topMargin = top;
            view.setLayoutParams(lp);
            view.setVisibility(width > 8 && height > 8 ? View.VISIBLE : View.INVISIBLE);
            view.bringToFront();
        });
    }

    public final class Bridge {
        @JavascriptInterface public void updateBrokerBounds(int index, float x, float y, float width, float height) { setBrokerBounds(index, x, y, width, height); }
        @JavascriptInterface public void openBroker(int index) {
            if (index >= 0 && index < 3) runOnUiThread(() -> Toast.makeText(MainActivity.this, NAMES[index] + " hiển thị trong khung riêng", Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void closeBroker() { runOnUiThread(() -> { for (WebView v : brokerViews) if (v != null) v.setVisibility(View.INVISIBLE); }); }
    }

    @Override protected void onResume() { super.onResume(); if (appView != null) appView.onResume(); for (WebView v : brokerViews) if (v != null) v.onResume(); }
    @Override protected void onPause() { for (WebView v : brokerViews) if (v != null) v.onPause(); if (appView != null) appView.onPause(); CookieManager.getInstance().flush(); super.onPause(); }
    @Override public void onBackPressed() { for (WebView v : brokerViews) if (v != null && v.getVisibility() == View.VISIBLE && v.canGoBack()) { v.goBack(); return; } super.onBackPressed(); }
    @Override protected void onDestroy() {
        for (int i=0;i<brokerViews.length;i++) { WebView v=brokerViews[i]; if(v!=null){try{v.stopLoading();root.removeView(v);v.destroy();}catch(Exception ignored){} brokerViews[i]=null;} }
        if(appView!=null){try{appView.removeJavascriptInterface("Android");appView.stopLoading();root.removeView(appView);appView.destroy();}catch(Exception ignored){} appView=null;}
        super.onDestroy();
    }
}
