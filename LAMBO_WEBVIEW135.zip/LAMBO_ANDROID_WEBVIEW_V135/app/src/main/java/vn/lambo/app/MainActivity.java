package vn.lambo.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.view.Gravity;
import android.graphics.Color;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.widget.TextView;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;

public class MainActivity extends Activity {
    private static final String TAG="LAMBO";
    private static final String[] URLS={"https://luxwin3.net/login","https://coltra1.net/login","https://fiaura1.net/login"};
    private final WebView[] brokers=new WebView[3];
    private final int[][] bounds=new int[3][4];
    private FrameLayout root;
    private WebView appView;
    private int active=-1;
    private boolean brokerExpanded=false;
    private TextView collapseButton;
    private TextView diagnosticButton;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        CookieManager.getInstance().setAcceptCookie(true);
        root=new FrameLayout(this); setContentView(root);
        appView=new WebView(this);
        WebSettings as=appView.getSettings(); as.setJavaScriptEnabled(true); as.setDomStorageEnabled(true);
        as.setAllowFileAccess(true); as.setLoadsImagesAutomatically(true);
        appView.setWebChromeClient(new WebChromeClient());
        appView.setWebViewClient(new WebViewClient());
        appView.addJavascriptInterface(new Bridge(-1),"Android");
        root.addView(appView,new FrameLayout.LayoutParams(-1,-1));
        for(int i=0;i<3;i++)createBroker(i);
        appView.loadUrl("file:///android_asset/index.html");
    }

    private void injectClockProbe(WebView v){
        if(v==null)return;
        try(InputStream in=getAssets().open("broker_clock_probe.js");ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[2048];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
            v.evaluateJavascript(out.toString("UTF-8"),null);
        }catch(Exception e){Log.w(TAG,"Broker clock probe unavailable",e);}
    }

    private void injectBalanceProbe(WebView v){
        if(v==null)return;
        try(InputStream in=getAssets().open("broker_balance_probe.js");ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[2048];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
            v.evaluateJavascript(out.toString("UTF-8"),null);
        }catch(Exception e){Log.w(TAG,"Broker balance probe unavailable",e);}
    }

    private void setChartOnly(WebView v, boolean enabled){
        if(v==null)return;
        try(InputStream in=getAssets().open("broker_chart_focus.js");
            ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[4096]; int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
            String script=out.toString("UTF-8")+"\nwindow.lamboSetChartOnly("+(enabled?"true":"false")+");";
            v.evaluateJavascript(script,null);
        }catch(Exception e){Log.w(TAG,"Chart focus script unavailable",e);}
    }

    private void setColtraMiniMode(WebView v, boolean enabled){
        if(v==null)return;
        try(InputStream in=getAssets().open("coltra1_mini_filter.js");
            ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[4096]; int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
            String script=out.toString("UTF-8")+"\nwindow.lamboSetColtraMiniMode("+(enabled?"true":"false")+");";
            v.evaluateJavascript(script,null);
        }catch(Exception e){Log.w(TAG,"COLTRA1 mini filter unavailable",e);}
    }

    private void setBrokerDiagnostic(WebView v,int index,boolean enabled){
        if(v==null)return;
        try(InputStream in=getAssets().open("broker_chart_diagnostic.js");
            ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[4096]; int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
            String[] names={"LUXWIN","COLTRA1","FIAURA1"};
            String name=names[index];
            String script=out.toString("UTF-8")+"\nwindow.lamboDiagnosticMode("+(enabled?"true":"false")+",'"+name+"');";
            v.evaluateJavascript(script,null);
        }catch(Exception e){Log.w(TAG,"Broker diagnostic script unavailable",e);}
    }

    private void createBroker(int i){
        final int index=i;
        WebView w=new WebView(this); brokers[i]=w;
        // Expose the clipboard bridge to each broker WebView so diagnostic details can be copied.
        w.addJavascriptInterface(new Bridge(i),"Android");
        WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setLoadsImagesAutomatically(true);
        // Make broker pages fit the narrow card and keep vertical swipes inside the broker.
        s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true); s.setTextZoom(100); w.setInitialScale(45);
        s.setSupportZoom(true); s.setBuiltInZoomControls(true); s.setDisplayZoomControls(false);
        w.setVerticalScrollBarEnabled(true); w.setHorizontalScrollBarEnabled(false);
        w.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        w.setOnTouchListener((view,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN || event.getAction()==MotionEvent.ACTION_MOVE){
                view.getParent().requestDisallowInterceptTouchEvent(true);
            }
            if(event.getAction()==MotionEvent.ACTION_UP || event.getAction()==MotionEvent.ACTION_CANCEL){
                view.getParent().requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });
        s.setSupportMultipleWindows(false); s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w,true);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String url){
                injectClockProbe(v);
                injectBalanceProbe(v);
                setChartOnly(v,false);
                if(index==1)setColtraMiniMode(v,!brokerExpanded);
                setBrokerDiagnostic(v,index,brokerExpanded);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){
                String scheme=req.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme)||"http".equalsIgnoreCase(scheme));
            }
            @Override public void onReceivedError(WebView v,WebResourceRequest req,android.webkit.WebResourceError err){
                if(req.isForMainFrame())Log.e(TAG,"Broker "+index+" load error: "+err.getDescription());
            }
            @Override public boolean onRenderProcessGone(WebView v,android.webkit.RenderProcessGoneDetail d){
                v.setVisibility(View.INVISIBLE);
                Log.e(TAG,"Broker renderer stopped: "+index);
                return true;
            }
        });
        w.setVisibility(View.INVISIBLE);
        root.addView(w,new FrameLayout.LayoutParams(1,1));
    }

    private void setBounds(int i,float x,float y,float width,float height){
        if(i<0||i>2)return;
        final float den=getResources().getDisplayMetrics().density;
        final int l=Math.round(x*den),t=Math.round(y*den);
        final int wi=Math.max(1,Math.round(width*den)),he=Math.max(1,Math.round(height*den));
        runOnUiThread(()->{
            if(brokerExpanded)return;
            WebView v=brokers[i]; if(v==null||isFinishing()||isDestroyed())return;
            bounds[i]=new int[]{l,t,wi,he};
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(wi,he);
            lp.leftMargin=l;lp.topMargin=t;v.setLayoutParams(lp);
            v.setVisibility(width>0&&height>0?View.VISIBLE:View.INVISIBLE);
            if(i==active)v.bringToFront();
        });
    }

    private void expandBroker(int i){
        if(i<0||i>2)return;
        runOnUiThread(()->{
            active=i; brokerExpanded=true;
            for(int n=0;n<3;n++){
                WebView v=brokers[n];
                if(v==null)continue;
                if(n==i){
                    v.setLayoutParams(new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                    v.setVisibility(View.VISIBLE); v.bringToFront(); v.onResume();
                    v.setInitialScale(100);
                    setChartOnly(v,false);
                    if(i==1)setColtraMiniMode(v,false);
                    setBrokerDiagnostic(v,i,true);
                    String current=v.getUrl();
                    if(current==null||current.isEmpty())v.loadUrl(URLS[i]);
                }else v.setVisibility(View.INVISIBLE);
            }
            if(collapseButton==null){
                collapseButton=new TextView(this);
                collapseButton.setText("Thu nhỏ  ✕");
                collapseButton.setContentDescription("Thu nhỏ về ba khung sàn");
                collapseButton.setTextColor(Color.WHITE);
                collapseButton.setTextSize(16);
                collapseButton.setGravity(Gravity.CENTER);
                collapseButton.setPadding(18,12,18,12);
                collapseButton.setBackgroundColor(Color.rgb(20,105,180));
                collapseButton.setElevation(20);
                collapseButton.setOnClickListener(v->collapseBroker());
            }
            if(collapseButton.getParent()==null){
                FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP|Gravity.END);
                bp.topMargin=12; bp.rightMargin=12;
                root.addView(collapseButton,bp);
            }
            collapseButton.bringToFront();

            if(diagnosticButton==null){
                diagnosticButton=new TextView(this);
                diagnosticButton.setText("CHẨN ĐOÁN");
                diagnosticButton.setTextColor(Color.WHITE);
                diagnosticButton.setTextSize(13);
                diagnosticButton.setGravity(Gravity.CENTER);
                diagnosticButton.setPadding(14,10,14,10);
                diagnosticButton.setBackgroundColor(Color.rgb(20,105,180));
                diagnosticButton.setElevation(22);
                diagnosticButton.setContentDescription("Mở kiểm tra vùng biểu đồ");
                diagnosticButton.setOnClickListener(view->{
                    WebView target=brokers[active];
                    if(target==null)return;
                    int selected=active;
                    setBrokerDiagnostic(target,selected,true);
                    target.evaluateJavascript(
                        "if(window.lamboDiagnosticMode){window.lamboDiagnosticMode(true,'"+new String[]{"LUXWIN","COLTRA1","FIAURA1"}[selected]+"');}" +
                        "var b=document.getElementById('lamboDiagButton');if(b)b.click();",
                        null
                    );
                });
            }
            if(diagnosticButton.getParent()==null){
                FrameLayout.LayoutParams dp=new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP|Gravity.START);
                dp.topMargin=12; dp.leftMargin=12;
                root.addView(diagnosticButton,dp);
            }
            diagnosticButton.bringToFront();
            collapseButton.bringToFront();
        });
    }
    private void collapseBroker(){
        runOnUiThread(()->{
            brokerExpanded=false;
            if(collapseButton!=null&&collapseButton.getParent()==root)root.removeView(collapseButton);
            if(diagnosticButton!=null&&diagnosticButton.getParent()==root)root.removeView(diagnosticButton);
            for(int i=0;i<3;i++){
                WebView v=brokers[i]; if(v==null)continue;
                int[] b=bounds[i];
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(1,b[2]),Math.max(1,b[3]));
                lp.leftMargin=b[0]; lp.topMargin=b[1]; v.setLayoutParams(lp);
                v.setVisibility(b[2]>0&&b[3]>0?View.VISIBLE:View.INVISIBLE);
                v.setInitialScale(45);
                setChartOnly(v,false);
                if(i==1)setColtraMiniMode(v,true);
                setBrokerDiagnostic(v,i,false);
                v.onResume();
            }
            if(appView!=null)appView.bringToFront();
            for(int i=0;i<3;i++)if(brokers[i]!=null&&bounds[i][2]>0&&bounds[i][3]>0)brokers[i].bringToFront();
            if(appView!=null)appView.evaluateJavascript("if(typeof onBrokerCollapsed==='function')onBrokerCollapsed();",null);
        });
    }

    private void publishNearestBrokerClock(){
        android.content.SharedPreferences p=getSharedPreferences("broker_clock",MODE_PRIVATE);
        long now=System.currentTimeMillis(),bestAt=0;int best=-1,bestSeconds=-1;
        for(int i=0;i<3;i++){
            long at=p.getLong("at_"+i,0L);int sec=p.getInt("seconds_"+i,-1);String phase=p.getString("phase_"+i,"UNKNOWN");
            if(sec<0||now-at>1800||!("ENTRY".equals(phase)||"RESULT".equals(phase)))continue;
            if(best<0||sec<bestSeconds){best=i;bestSeconds=sec;bestAt=at;}
        }
        String[] names={"LUXWIN","COLTRA1","FIAURA1"};
        if(best>=0){String phase=p.getString("phase_"+best,"UNKNOWN");p.edit().putInt("seconds",bestSeconds).putLong("at",bestAt).putString("site",names[best]).putString("phase",phase).apply();}
        else p.edit().putInt("seconds",-1).putLong("at",0L).putString("site","UNKNOWN").putString("phase","UNKNOWN").apply();
        if(appView!=null){
            final int sec=bestSeconds;final long at=bestAt;final String site=best>=0?names[best]:"UNKNOWN";final String phase=best>=0?p.getString("phase_"+best,"UNKNOWN"):"UNKNOWN";
            runOnUiThread(()->appView.evaluateJavascript("if(window.onBrokerClockUpdate)window.onBrokerClockUpdate("+sec+","+at+",'"+site+"','"+phase+"')",null));
        }
    }

    public final class Bridge{
        private final int siteIndex;
        Bridge(int index){siteIndex=index;}
        @JavascriptInterface public void reportBrokerClock(int seconds,String phase){
            if(siteIndex<0||siteIndex>2||seconds<0||seconds>3600)return;
            if(!"ENTRY".equals(phase)&&!"RESULT".equals(phase))phase="UNKNOWN";
            long now=System.currentTimeMillis();
            getSharedPreferences("broker_clock",MODE_PRIVATE).edit()
                .putInt("seconds_"+siteIndex,seconds).putLong("at_"+siteIndex,now).putString("phase_"+siteIndex,phase).apply();
            publishNearestBrokerClock();
        }
        @JavascriptInterface public void reportBrokerBalance(String accountType,String amount,String currency,String rawText){
            if(siteIndex<0||siteIndex>2||amount==null||amount.length()>40)return;
            if(!"DEMO".equals(accountType)&&!"LIVE".equals(accountType))return;
            try{
                double value=Double.parseDouble(amount);
                if(!Double.isFinite(value)||value<0||value>1.0e15)return;
                String[] names={"Luxwin","Coltra1","Fiaura1"};
                String key="balance_"+accountType.toLowerCase()+"_"+siteIndex;
                getSharedPreferences("broker_balance",MODE_PRIVATE).edit()
                    .putString(key,amount).putString(key+"_currency",currency==null?"":currency)
                    .putLong(key+"_at",System.currentTimeMillis()).putString(key+"_raw",rawText==null?"":rawText.substring(0,Math.min(160,rawText.length()))).apply();
                String js="if(window.onBrokerBalanceUpdate)window.onBrokerBalanceUpdate('"+accountType+"',"+siteIndex+",'"+amount+"','"+(currency==null?"":currency).replace("'","")+"',"+System.currentTimeMillis()+")";
                runOnUiThread(()->{if(appView!=null)appView.evaluateJavascript(js,null);});
            }catch(Exception ignored){}
        }
        @JavascriptInterface public void copyDiagnostic(String value){
            final String safe=value==null?"":value;
            runOnUiThread(()->{
                ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                if(cm!=null)cm.setPrimaryClip(ClipData.newPlainText("LAM BO chart diagnostic",safe));
                android.widget.Toast.makeText(MainActivity.this,"Đã sao chép thông tin vùng biểu đồ",android.widget.Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void dispatchBrokerOrder(int index,String side,String amount,String accountMode,String requestId){
            if(index<0||index>2||side==null||amount==null||requestId==null)return;
            if(!"MUA".equals(side)&&!"BÁN".equals(side))return;
            if(!"DEMO".equals(accountMode)&&!"LIVE".equals(accountMode))return;
            final double stake;
            try{stake=Double.parseDouble(amount);}catch(Exception e){return;}
            if(!Double.isFinite(stake)||stake<=0||stake>1000000)return;
            android.content.SharedPreferences clock=getSharedPreferences("broker_clock",MODE_PRIVATE);
            long clockAt=clock.getLong("at_"+index,0L);
            String brokerPhase=clock.getString("phase_"+index,"UNKNOWN");
            int brokerSeconds=clock.getInt("seconds_"+index,-1);
            if(!"ENTRY".equals(brokerPhase)||brokerSeconds<0||System.currentTimeMillis()-clockAt>1800L){
                publishOrderStatus(index,requestId,"CHƯA GỬI","Chưa xác minh được pha CHỜ ĐẶT LỆNH của riêng sàn này");
                return;
            }
            runOnUiThread(()->{
                WebView target=brokers[index];
                if(target==null){publishOrderStatus(index,requestId,"CHƯA GỬI","WebView sàn chưa sẵn sàng");return;}
                try(InputStream in=getAssets().open("broker_order_dispatch.js");ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
                    String script=out.toString("UTF-8")+";window.LamboOrder.dispatch("+JSONObject.quote(side)+","+JSONObject.quote(amount)+","+JSONObject.quote(accountMode)+","+JSONObject.quote(requestId)+");";
                    publishOrderStatus(index,requestId,"ĐANG GỬI","Đã chuyển yêu cầu vào WebView; chưa xác nhận sàn nhận lệnh");
                    target.evaluateJavascript(script,null);
                }catch(Exception e){Log.e(TAG,"Order dispatcher unavailable",e);publishOrderStatus(index,requestId,"CHƯA GỬI","Không nạp được bộ điều khiển");}
            });
        }
        private void publishOrderStatus(int index,String requestId,String status,String detail){
            String js="if(window.onBrokerOrderStatus)window.onBrokerOrderStatus("+index+","+JSONObject.quote(requestId)+","+JSONObject.quote(status)+","+JSONObject.quote(detail)+");";
            runOnUiThread(()->{if(appView!=null)appView.evaluateJavascript(js,null);});
        }
        @JavascriptInterface public void reportOrderStatus(String requestId,String status,String detail){
            if(siteIndex<0||siteIndex>2||requestId==null||requestId.length()>80||status==null||status.length()>80)return;
            String safeDetail=detail==null?"":detail.substring(0,Math.min(180,detail.length()));
            runOnUiThread(()->publishOrderStatus(siteIndex,requestId,status,safeDetail));
        }
        @JavascriptInterface public int getBrokerTimerSeconds(){ return getSharedPreferences("broker_clock",MODE_PRIVATE).getInt("seconds",-1); }
        @JavascriptInterface public long getBrokerTimerAt(){ return getSharedPreferences("broker_clock",MODE_PRIVATE).getLong("at",0L); }
        @JavascriptInterface public String getBrokerTimerSite(){ return getSharedPreferences("broker_clock",MODE_PRIVATE).getString("site","UNKNOWN"); }
        @JavascriptInterface public String getBrokerTimerPhase(){ return getSharedPreferences("broker_clock",MODE_PRIVATE).getString("phase","UNKNOWN"); }

        @JavascriptInterface public void updateBrokerBounds(int i,float x,float y,float w,float h){setBounds(i,x,y,w,h);}
        @JavascriptInterface public void expandBroker(int i){MainActivity.this.expandBroker(i);}
        @JavascriptInterface public void openBroker(int i){
            if(i<0||i>2)return;
            runOnUiThread(()->{
                active=i;
                WebView v=brokers[i];
                int[] b=bounds[i];
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(1,b[2]),Math.max(1,b[3]));
                lp.leftMargin=b[0];lp.topMargin=b[1];v.setLayoutParams(lp);
                v.setVisibility(b[2]>0&&b[3]>0?View.VISIBLE:View.INVISIBLE);
                String current=v.getUrl();
                if(current==null||current.isEmpty())v.loadUrl(URLS[i]);
                v.onResume();
            });
        }
        @JavascriptInterface public void startAllBrokers(){
            runOnUiThread(()->{
                for(int i=0;i<3;i++){
                    WebView v=brokers[i]; if(v==null)continue;
                    int[] b=bounds[i];
                    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(1,b[2]),Math.max(1,b[3]));
                    lp.leftMargin=b[0];lp.topMargin=b[1];v.setLayoutParams(lp);
                    v.setVisibility(b[2]>0&&b[3]>0?View.VISIBLE:View.INVISIBLE);
                    String current=v.getUrl();
                    if(current==null||current.isEmpty())v.loadUrl(URLS[i]);
                    v.onResume();
                    setChartOnly(v,false);
                    setBrokerDiagnostic(v,i,false);
                }
            });
        }
        @JavascriptInterface public void closeBroker(){
            runOnUiThread(()->{active=-1;for(WebView v:brokers)if(v!=null)v.setVisibility(View.INVISIBLE);});
        }
    }
    @Override protected void onResume(){super.onResume();if(appView!=null)appView.onResume();for(WebView v:brokers)if(v!=null)v.onResume();}
    @Override protected void onPause(){for(WebView v:brokers)if(v!=null)v.onPause();if(appView!=null)appView.onPause();CookieManager.getInstance().flush();super.onPause();}
    @Override public void onBackPressed(){
        if(brokerExpanded){collapseBroker();return;}
        if(active>=0){
            WebView current=brokers[active];
            if(current!=null && current.canGoBack()) current.goBack();
            // Keep the broker displayed in its assigned card; Back does not close the broker frame.
            return;
        }
        if(appView!=null && appView.canGoBack()) appView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){if(collapseButton!=null&&collapseButton.getParent()==root)root.removeView(collapseButton);for(int i=0;i<3;i++){WebView v=brokers[i];if(v!=null){v.stopLoading();root.removeView(v);v.destroy();brokers[i]=null;}}if(appView!=null){appView.removeJavascriptInterface("Android");appView.stopLoading();root.removeView(appView);appView.destroy();}super.onDestroy();}
}
