package vn.lambo.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.graphics.Color;
import android.webkit.JavascriptInterface;

public class MainActivity extends Activity {
    private FrameLayout root;
    private WebView appView, brokerView;
    private boolean brokerVisible = false;
    private final String[] brokerUrls = {
        "https://luxwin3.net/",
        "https://coltra1.net/",
        "https://fiaura1.net/"
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        CookieManager.getInstance().setAcceptCookie(true);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5,10,23));

        appView = new WebView(this);
        configure(appView, true);
        appView.addJavascriptInterface(new Bridge(), "Android");
        appView.loadUrl("file:///android_asset/index.html");
        root.addView(appView, new FrameLayout.LayoutParams(-1,-1));

        brokerView = new WebView(this);
        configure(brokerView, false);
        brokerView.setVisibility(View.GONE);
        brokerView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme);
            }
        });
        root.addView(brokerView, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    private void configure(WebView view, boolean localApp) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(localApp);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        view.setWebChromeClient(new WebChromeClient());
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true);
    }

    private void openBroker(int index) {
        if (index < 0 || index >= brokerUrls.length) return;
        brokerVisible = true;
        brokerView.setVisibility(View.VISIBLE);
        appView.setVisibility(View.GONE);
        String target = brokerUrls[index];
        if (brokerView.getUrl() == null || !target.equals(brokerView.getUrl())) brokerView.loadUrl(target);
    }

    private void closeBroker() {
        brokerVisible = false;
        brokerView.setVisibility(View.GONE);
        appView.setVisibility(View.VISIBLE);
    }

    private class Bridge {
        @JavascriptInterface public void openBroker(final int index) {
            runOnUiThread(() -> openBroker(index));
        }
        @JavascriptInterface public void closeBroker() {
            runOnUiThread(() -> closeBroker());
        }
    }

    @Override public void onBackPressed() {
        if (brokerVisible) {
            if (brokerView.canGoBack()) brokerView.goBack(); else closeBroker();
        } else if (appView.canGoBack()) {
            appView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }
}
