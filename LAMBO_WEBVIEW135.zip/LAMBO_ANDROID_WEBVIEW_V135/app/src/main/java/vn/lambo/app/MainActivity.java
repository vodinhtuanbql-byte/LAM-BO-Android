package vn.lambo.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String TAG = "LAMBO";
    private static final String[] URLS = {
        "https://luxwin3.net/", "https://coltra1.net/", "https://fiaura1.net/"
    };
    private static final String[] NAMES = {"LUXWIN", "COLTRA1", "FIAURA1"};
    private FrameLayout root;
    private WebView appView;
    private final WebView[] brokerViews = new WebView[3];
    private final FrameLayout.LayoutParams[] brokerLayouts = new FrameLayout.LayoutParams[3];
    private final boolean[] loaded = new boolean[3];
    private final boolean[] failed = new boolean[3];
    private float density;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        density = getResources().getDisplayMetrics().density;
        CookieManager.getInstance().setAcceptCookie(true);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5, 12, 25));
        setContentView(root);
        createAppView();
        createBrokerViews();
    }

    private void createAppView() {
        appView = new WebView(this);
        WebSettings s = appView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        appView.setWebChromeClient(new WebChromeClient());
        appView.setWebViewClient(new WebViewClient());
        appView.addJavascriptInterface(new Bridge(), "Android");
        root.addView(appView, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        appView.loadUrl("file:///android_asset/index.html");
    }

    // Three independent WebViews stay in the three existing broker-card chart slots.
    private void createBrokerViews() {
        for (int i = 0; i < 3; i++) createBrokerView(i);
    }

    private void createBrokerView(final int index) {
        WebView w = new WebView(this);
        brokerViews[index] = w;
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                loaded[index] = false;
                failed[index] = false;
                Log.i(TAG, NAMES[index] + " loading: " + url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                loaded[index] = true;
                failed[index] = false;
                Log.i(TAG, NAMES[index] + " loaded: " + url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    failed[index] = true;
                    Log.e(TAG, NAMES[index] + " main-frame load error: " + error.getDescription());
                    Toast.makeText(MainActivity.this, NAMES[index] + ": không tải được, kiểm tra mạng", Toast.LENGTH_SHORT).show();
                }
            }
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                Log.e(TAG, NAMES[index] + " renderer gone");
                if (root != null) root.removeView(view);
                view.destroy();
                brokerViews[index] = null;
                loaded[index] = false;
                failed[index] = true;
                Toast.makeText(MainActivity.this, NAMES[index] + ": WebView bị dừng; mở lại ứng dụng để thử", Toast.LENGTH_LONG).show();
                return true;
            }
        });
        w.setBackgroundColor(Color.rgb(5, 11, 25));
        brokerLayouts[index] = new FrameLayout.LayoutParams(1, 1);
        root.addView(w, brokerLayouts[index]);
        w.setVisibility(View.INVISIBLE);
        // Load each platform in its own WebView; one failure does not replace the others.
        w.loadUrl(URLS[index]);
    }

    private void updateBrokerBounds(int index, float x, float y, float width, float height) {
        if (index < 0 || index > 2 || brokerViews[index] == null || brokerLayouts[index] == null) return;
        int left = Math.round(x * density);
        int top = Math.round(y * density);
        int w = Math.max(1, Math.round(width * density));
        int h = Math.max(1, Math.round(height * density));
        FrameLayout.LayoutParams p = brokerLayouts[index];
        p.width = w;
        p.height = h;
        p.leftMargin = left;
        p.topMargin = top;
        brokerViews[index].setLayoutParams(p);
        brokerViews[index].setVisibility(width > 0 && height > 0 ? View.VISIBLE : View.INVISIBLE);
    }

    private void openBroker(int index) {
        if (index < 0 || index > 2) return;
        runOnUiThread(() -> {
            if (brokerViews[index] == null) createBrokerView(index);
            Toast.makeText(this, "LAM BO: " + NAMES[index] + " đang chạy trong khung riêng", Toast.LENGTH_SHORT).show();
            if (failed[index] && brokerViews[index] != null) {
                failed[index] = false;
                brokerViews[index].reload();
            }
            updateAllBounds();
        });
    }

    private void updateAllBounds() {
        if (appView == null) return;
        appView.evaluateJavascript(
            "(function(){for(var i=0;i<3;i++){var e=document.getElementById('mini'+i);if(e){var r=e.getBoundingClientRect();" +
            "if(window.Android&&Android.updateBrokerBounds)Android.updateBrokerBounds(i,r.left,r.top,r.width,r.height);}}})()", null);
    }

    private void closeBroker(int index) {
        if (index < 0 || index > 2 || brokerViews[index] == null) return;
        runOnUiThread(() -> brokerViews[index].setVisibility(View.INVISIBLE));
    }

    public final class Bridge {
        @JavascriptInterface public void openBroker(final int index) { openBroker(index); }
        @JavascriptInterface public void closeBroker(final int index) { closeBroker(index); }
        @JavascriptInterface public void updateBrokerBounds(final int index, final float x, final float y,
                                                              final float width, final float height) {
            runOnUiThread(() -> updateBrokerBounds(index, x, y, width, height));
        }
    }

    @Override public void onBackPressed() {
        // Keep the three platform sessions alive; Back first navigates the focused web content if possible.
        for (int i = 2; i >= 0; i--) {
            WebView w = brokerViews[i];
            if (w != null && w.hasFocus() && w.canGoBack()) { w.goBack(); return; }
        }
        super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
        if (appView != null) appView.onPause();
        for (WebView w : brokerViews) if (w != null) w.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (appView != null) appView.onResume();
        for (WebView w : brokerViews) if (w != null) w.onResume();
        if (appView != null) appView.postDelayed(this::updateAllBounds, 350);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && appView != null) appView.postDelayed(this::updateAllBounds, 180);
    }

    @Override protected void onDestroy() {
        for (int i = 0; i < 3; i++) {
            WebView w = brokerViews[i];
            if (w != null) {
                w.stopLoading();
                root.removeView(w);
                w.destroy();
                brokerViews[i] = null;
            }
        }
        if (appView != null) {
            appView.stopLoading();
            appView.removeJavascriptInterface("Android");
            root.removeView(appView);
            appView.destroy();
            appView = null;
        }
        super.onDestroy();
    }
}
