package vn.lambo.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.view.Gravity;
import android.graphics.Color;
import android.widget.TextView;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.util.Log;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;

public class MainActivity extends Activity {
    private static final String TAG="LAMBO";
    private static final String[] URLS={"https://luxwin3.net/login","https://coltra1.net/login","https://fiaura1.net/login"};
    private final WebView[] brokers=new WebView[3];
    private final int[][] bounds=new int[3][4];
    private FrameLayout root;
    private WebView appView;
    private int active=-1;
    private boolean brokerExpanded=false;
    private TextView collapseButton;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        CookieManager.getInstance().setAcceptCookie(true);
        root=new FrameLayout(this); setContentView(root);
        appView=new WebView(this);
        WebSettings as=appView.getSettings(); as.setJavaScriptEnabled(true); as.setDomStorageEnabled(true);
        as.setAllowFileAccess(true); as.setLoadsImagesAutomatically(true);
        appView.setWebChromeClient(new WebChromeClient());
        appView.setWebViewClient(new WebViewClient());
        appView.addJavascriptInterface(new Bridge(),"Android");
        root.addView(appView,new FrameLayout.LayoutParams(-1,-1));
        for(int i=0;i<3;i++)createBroker(i);
        appView.loadUrl("file:///android_asset/index.html");
    }

    private void setChartOnly(WebView v, boolean enabled){
        if(v==null)return;
        try(InputStream in=getAssets().open("broker_chart_focus.js");
            ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[4096]; int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
            String script=out.toString("UTF-8")+"\nwindow.lamboSetChartOnly("+(enabled?"true":"false")+");";
            v.evaluateJavascript(script,null);
        }catch(Exception e){Log.w(TAG,"Chart focus script unavailable",e);}
    }

    private void setBrokerDiagnostic(WebView v,int index,boolean enabled){
        if(v==null)return;
        try(InputStream in=getAssets().open("broker_chart_diagnostic.js");
            ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[4096]; int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
            String[] names={"LUXWIN","COLTRA1","FIAURA1"};
            String name=names[index];
            String script=out.toString("UTF-8")+"\\nwindow.lamboDiagnosticMode("+(enabled?"true":"false")+",'"+name+"');";
            v.evaluateJavascript(script,null);
        }catch(Exception e){Log.w(TAG,"Broker diagnostic script unavailable",e);}
    }

    private void createBroker(int i){
        final int index=i;
        WebView w=new WebView(this); brokers[i]=w;
        WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setLoadsImagesAutomatically(true);
        // Make broker pages fit the narrow card and keep vertical swipes inside the broker.
        s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true); s.setTextZoom(100); w.setInitialScale(45);
        s.setSupportZoom(true); s.setBuiltInZoomControls(true); s.setDisplayZoomControls(false);
        w.setVerticalScrollBarEnabled(true); w.setHorizontalScrollBarEnabled(false);
        w.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        w.setOnTouchListener((view,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN || event.getAction()==MotionEvent.ACTION_MOVE){
                view.getParent().requestDisallowInterceptTouchEvent(true);
            }
            if(event.getAction()==MotionEvent.ACTION_UP || event.getAction()==MotionEvent.ACTION_CANCEL){
                view.getParent().requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });
        s.setSupportMultipleWindows(false); s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w,true);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String url){
                setChartOnly(v,false);
                setBrokerDiagnostic(v,index,brokerExpanded);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){
                String scheme=req.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme)||"http".equalsIgnoreCase(scheme));
            }
            @Override public void onReceivedError(WebView v,WebResourceRequest req,android.webkit.WebResourceError err){
                if(req.isForMainFrame())Log.e(TAG,"Broker "+index+" load error: "+err.getDescription());
            }
            @Override public boolean onRenderProcessGone(WebView v,android.webkit.RenderProcessGoneDetail d){
                v.setVisibility(View.INVISIBLE);
                Log.e(TAG,"Broker renderer stopped: "+index);
                return true;
            }
        });
        w.setVisibility(View.INVISIBLE);
        root.addView(w,new FrameLayout.LayoutParams(1,1));
    }

    private void setBounds(int i,float x,float y,float width,float height){
        if(i<0||i>2)return;
        final float den=getResources().getDisplayMetrics().density;
        final int l=Math.round(x*den),t=Math.round(y*den);
        final int wi=Math.max(1,Math.round(width*den)),he=Math.max(1,Math.round(height*den));
        runOnUiThread(()->{
            if(brokerExpanded)return;
            WebView v=brokers[i]; if(v==null||isFinishing()||isDestroyed())return;
            bounds[i]=new int[]{l,t,wi,he};
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(wi,he);
            lp.leftMargin=l;lp.topMargin=t;v.setLayoutParams(lp);
            v.setVisibility(width>0&&height>0?View.VISIBLE:View.INVISIBLE);
            if(i==active)v.bringToFront();
        });
    }

    private void expandBroker(int i){
        if(i<0||i>2)return;
        runOnUiThread(()->{
            active=i; brokerExpanded=true;
            for(int n=0;n<3;n++){
                WebView v=brokers[n];
                if(v==null)continue;
                if(n==i){
                    v.setLayoutParams(new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                    v.setVisibility(View.VISIBLE); v.bringToFront(); v.onResume();
                    v.setInitialScale(100);
                    setChartOnly(v,false);
                    setBrokerDiagnostic(v,i,true);
                    String current=v.getUrl();
                    if(current==null||current.isEmpty())v.loadUrl(URLS[i]);
                }else v.setVisibility(View.INVISIBLE);
            }
            if(collapseButton==null){
                collapseButton=new TextView(this);
                collapseButton.setText("Thu nhỏ  ✕");
                collapseButton.setContentDescription("Thu nhỏ về ba khung sàn");
                collapseButton.setTextColor(Color.WHITE);
                collapseButton.setTextSize(16);
                collapseButton.setGravity(Gravity.CENTER);
                collapseButton.setPadding(18,12,18,12);
                collapseButton.setBackgroundColor(Color.rgb(20,105,180));
                collapseButton.setElevation(20);
                collapseButton.setOnClickListener(v->collapseBroker());
            }
            if(collapseButton.getParent()==null){
                FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP|Gravity.END);
                bp.topMargin=12; bp.rightMargin=12;
                root.addView(collapseButton,bp);
            }
            collapseButton.bringToFront();
        });
    }
    private void collapseBroker(){
        runOnUiThread(()->{
            brokerExpanded=false;
            if(collapseButton!=null&&collapseButton.getParent()==root)root.removeView(collapseButton);
            for(int i=0;i<3;i++){
                WebView v=brokers[i]; if(v==null)continue;
                int[] b=bounds[i];
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(1,b[2]),Math.max(1,b[3]));
                lp.leftMargin=b[0]; lp.topMargin=b[1]; v.setLayoutParams(lp);
                v.setVisibility(b[2]>0&&b[3]>0?View.VISIBLE:View.INVISIBLE);
                v.setInitialScale(45);
                setChartOnly(v,false);
                setBrokerDiagnostic(v,i,false);
                v.onResume();
            }
            if(appView!=null)appView.bringToFront();
            for(int i=0;i<3;i++)if(brokers[i]!=null&&bounds[i][2]>0&&bounds[i][3]>0)brokers[i].bringToFront();
            if(appView!=null)appView.evaluateJavascript("if(typeof onBrokerCollapsed==='function')onBrokerCollapsed();",null);
        });
    }

    public final class Bridge{
        @JavascriptInterface public int getBrokerTimerSeconds(){ return getSharedPreferences("broker_clock",MODE_PRIVATE).getInt("seconds",-1); }
        @JavascriptInterface public long getBrokerTimerAt(){ return getSharedPreferences("broker_clock",MODE_PRIVATE).getLong("at",0L); }

        @JavascriptInterface public void updateBrokerBounds(int i,float x,float y,float w,float h){setBounds(i,x,y,w,h);}
        @JavascriptInterface public void expandBroker(int i){MainActivity.this.expandBroker(i);}
        @JavascriptInterface public void openBroker(int i){
            if(i<0||i>2)return;
            runOnUiThread(()->{
                active=i;
                WebView v=brokers[i];
                int[] b=bounds[i];
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(1,b[2]),Math.max(1,b[3]));
                lp.leftMargin=b[0];lp.topMargin=b[1];v.setLayoutParams(lp);
                v.setVisibility(b[2]>0&&b[3]>0?View.VISIBLE:View.INVISIBLE);
                String current=v.getUrl();
                if(current==null||current.isEmpty())v.loadUrl(URLS[i]);
                v.onResume();
            });
        }
        @JavascriptInterface public void startAllBrokers(){
            runOnUiThread(()->{
                for(int i=0;i<3;i++){
                    WebView v=brokers[i]; if(v==null)continue;
                    int[] b=bounds[i];
                    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(1,b[2]),Math.max(1,b[3]));
                    lp.leftMargin=b[0];lp.topMargin=b[1];v.setLayoutParams(lp);
                    v.setVisibility(b[2]>0&&b[3]>0?View.VISIBLE:View.INVISIBLE);
                    String current=v.getUrl();
                    if(current==null||current.isEmpty())v.loadUrl(URLS[i]);
                    v.onResume();
                    setChartOnly(v,false);
                    setBrokerDiagnostic(v,i,false);
                }
            });
        }
        @JavascriptInterface public void closeBroker(){
            runOnUiThread(()->{active=-1;for(WebView v:brokers)if(v!=null)v.setVisibility(View.INVISIBLE);});
        }
    }
    @Override protected void onResume(){super.onResume();if(appView!=null)appView.onResume();for(WebView v:brokers)if(v!=null)v.onResume();}
    @Override protected void onPause(){for(WebView v:brokers)if(v!=null)v.onPause();if(appView!=null)appView.onPause();CookieManager.getInstance().flush();super.onPause();}
    @Override public void onBackPressed(){
        if(brokerExpanded){collapseBroker();return;}
        if(active>=0){
            WebView current=brokers[active];
            if(current!=null && current.canGoBack()) current.goBack();
            // Keep the broker displayed in its assigned card; Back does not close the broker frame.
            return;
        }
        if(appView!=null && appView.canGoBack()) appView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){if(collapseButton!=null&&collapseButton.getParent()==root)root.removeView(collapseButton);for(int i=0;i<3;i++){WebView v=brokers[i];if(v!=null){v.stopLoading();root.removeView(v);v.destroy();brokers[i]=null;}}if(appView!=null){appView.removeJavascriptInterface("Android");appView.stopLoading();root.removeView(appView);appView.destroy();}super.onDestroy();}
}
