package vn.lambo.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private static final String[] URLS = {
        "https://luxwin3.net/",
        "https://coltra1.net/",
        "https://fiaura1.net/"
    };
    private static final String[] NAMES = {"LUXWIN", "COLTRA1", "FIAURA1"};
    private FrameLayout root;
    private WebView appView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new FrameLayout(this);
        setContentView(root);
        appView = new WebView(this);
        WebSettings s = appView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        appView.setWebChromeClient(new WebChromeClient());
        appView.setWebViewClient(new WebViewClient());
        appView.addJavascriptInterface(new Bridge(), "Android");
        root.addView(appView, new FrameLayout.LayoutParams(-1, -1));
        appView.loadUrl("file:///android_asset/index.html");
    }

    public final class Bridge {
        @JavascriptInterface public void openBroker(int index) {
            if (index < 0 || index >= URLS.length) return;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                Intent intent = new Intent(MainActivity.this, BrokerActivity.class);
                intent.putExtra(BrokerActivity.EXTRA_URL, URLS[index]);
                intent.putExtra(BrokerActivity.EXTRA_NAME, NAMES[index]);
                startActivity(intent);
            });
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (appView != null) appView.onResume();
    }

    @Override protected void onPause() {
        if (appView != null) appView.onPause();
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (appView != null && appView.canGoBack()) appView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (appView != null) {
            appView.removeJavascriptInterface("Android");
            appView.stopLoading();
            root.removeView(appView);
            appView.destroy();
            appView = null;
        }
        super.onDestroy();
    }
}
