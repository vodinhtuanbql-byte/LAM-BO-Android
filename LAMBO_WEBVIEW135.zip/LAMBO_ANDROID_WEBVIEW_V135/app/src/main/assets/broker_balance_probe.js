(function(){
  if(window.__lamboBalanceProbeV1)return;
  window.__lamboBalanceProbeV1=true;
  const norm=s=>(s||'').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const visible=e=>{if(!e||!e.getBoundingClientRect)return false;const r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>0&&r.height>0&&c.display!=='none'&&c.visibility!=='hidden'&&Number(c.opacity||1)>0;};
  function accountType(el){
    let n=el;
    for(let i=0;i<5&&n;i++,n=n.parentElement){
      const t=norm((n.innerText||'').slice(0,500));
      const d=/\b(demo|practice|virtual|trial)\b/.test(t)||/thu nghiem|tai khoan ao/.test(t);
      const l=/\b(real|live)\b/.test(t)||/tai khoan that|tai khoan thuc/.test(t);
      if(d&&!l)return 'DEMO'; if(l&&!d)return 'LIVE';
    }
    // Many broker interfaces expose a selected account-mode tab outside the balance node.
    const nodes=[...document.querySelectorAll('button,[role="tab"],[aria-pressed],.active,.selected,[class*="active"],[class*="selected"]')];
    let d=false,l=false;
    for(const e of nodes){if(!visible(e))continue;const t=norm((e.innerText||e.getAttribute('aria-label')||'').trim());if(!t||t.length>70)continue;
      if(/\b(demo|practice|virtual)\b/.test(t)||/thu nghiem/.test(t))d=true;
      if(/\b(real|live)\b/.test(t)||/tai khoan thuc/.test(t))l=true;
    }
    if(d&&!l)return 'DEMO';if(l&&!d)return 'LIVE';return null;
  }
  function parseAmount(text,el){
    const s=(text||'').replace(/\u00a0/g,' ').trim();
    // Accept only an explicit currency marker or a nearby balance/wallet label.
    const currency=(s.match(/USDT|USD|USDC|EUR|BTC|\$/i)||[])[0]||'';
    const label=/balance|wallet|available|account|so du|vi tien|tai san/i.test(norm(s+' '+(el&&el.className||'')+' '+(el&&el.id||'')));
    if(!currency&&!label)return null;
    const matches=s.match(/(?:^|[^\w])(?:\$\s*)?\d[\d., ]*(?:\d)?/g)||[];
    for(const m of matches){
      let v=m.trim().replace(/^\$\s*/,'').replace(/\s/g,'');if(!v)continue;
      // Normalize common US/European separators without changing displayed numeric value.
      if(v.includes(',')&&v.includes('.')){if(v.lastIndexOf(',')>v.lastIndexOf('.'))v=v.replace(/\./g,'').replace(',','.');else v=v.replace(/,/g,'');}
      else if(v.includes(',')){const tail=v.length-v.lastIndexOf(',')-1;v=tail===3?v.replace(/,/g,''):v.replace(',','.');}
      if(/^\d+(?:\.\d+)?$/.test(v)){const n=Number(v);if(Number.isFinite(n)&&n>=0)return {amount:String(n),currency};}
    }
    // Explicit zero is valid and must not be discarded by truthy checks.
    if(/(?:^|\D)0(?:[.,]0+)?(?:\D|$)/.test(s)&&(currency||label))return {amount:'0',currency};
    return null;
  }
  function scan(){
    try{
      const selector='[class*="balance" i],[id*="balance" i],[class*="wallet" i],[id*="wallet" i],[data-testid*="balance" i],[aria-label*="balance" i]';
      const els=[...document.querySelectorAll(selector)];
      for(const el of els){
        if(!visible(el))continue;
        const txt=(el.innerText||el.getAttribute('aria-label')||'').trim();if(!txt||txt.length>180)continue;
        const parsed=parseAmount(txt,el);if(!parsed)continue;
        const type=accountType(el);if(!type)continue;
        const sig=type+'|'+parsed.amount+'|'+parsed.currency;
        if(el.__lamboBalanceSig===sig&&Date.now()-(el.__lamboBalanceAt||0)<4000)continue;
        el.__lamboBalanceSig=sig;el.__lamboBalanceAt=Date.now();
        if(window.Android&&typeof Android.reportBrokerBalance==='function')Android.reportBrokerBalance(type,parsed.amount,parsed.currency,txt);
        break;
      }
    }catch(e){}
  }
  scan();setInterval(scan,1800);
  const observer=new MutationObserver(()=>{if(!window.__lamboBalanceQueued){window.__lamboBalanceQueued=true;setTimeout(()=>{window.__lamboBalanceQueued=false;scan();},350);}});
  try{observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true});}catch(e){}
})();
