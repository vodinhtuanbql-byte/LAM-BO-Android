
(function(){
  if(window.__lamboDiagLoaded) return;
  window.__lamboDiagLoaded=true;
  var panel=null, button=null, clearButton=null, candidates=[];
  function style(el,css){Object.keys(css).forEach(function(k){el.style.setProperty(k,css[k],'important');});}
  function removeHighlight(){
    document.querySelectorAll('[data-lambo-diag-selected="1"]').forEach(function(el){
      el.style.outline=el.getAttribute('data-lambo-diag-old-outline')||'';
      el.style.outlineOffset=el.getAttribute('data-lambo-diag-old-offset')||'';
      el.removeAttribute('data-lambo-diag-selected');
      el.removeAttribute('data-lambo-diag-old-outline');
      el.removeAttribute('data-lambo-diag-old-offset');
    });
  }
  function showClearButton(){
    if(clearButton&&clearButton.parentNode)return;
    clearButton=document.createElement('button');
    clearButton.type='button';
    clearButton.textContent='BỎ CHỌN VIỀN VÀNG';
    style(clearButton,{position:'fixed',right:'10px',bottom:'18px',zIndex:'2147483647',padding:'10px 12px',background:'#1769aa',color:'#fff',border:'2px solid #9bdcff',borderRadius:'8px',fontWeight:'800',fontSize:'13px'});
    clearButton.addEventListener('click',function(){removeHighlight();if(clearButton&&clearButton.parentNode)clearButton.parentNode.removeChild(clearButton);clearButton=null;});
    document.body.appendChild(clearButton);
  }
  function short(s,n){s=(s||'').toString().replace(/\s+/g,' ').trim();return s.length>n?s.slice(0,n-1)+'…':s;}
  function describe(el){
    var r=el.getBoundingClientRect(), cs=getComputedStyle(el);
    var cl=typeof el.className==='string'?el.className:(el.className&&el.className.baseVal)||'';
    var id=el.id?'#'+el.id:'';
    var cn=short(cl,90);
    return {el:el,tag:el.tagName.toLowerCase(),id:id,cls:cn,w:Math.round(r.width),h:Math.round(r.height),
      x:Math.round(r.left),y:Math.round(r.top),can:el.querySelectorAll('canvas').length,
      svg:el.querySelectorAll('svg').length,display:cs.display};
  }
  function scan(){
    var map=new Map();
    function add(el,weight){
      if(!el||el===document.body||el===document.documentElement)return;
      var d=describe(el);
      if(d.w<140||d.h<90||d.display==='none')return;
      var prev=map.get(el); if(!prev||weight>prev.weight)map.set(el,{...d,weight:weight});
    }
    document.querySelectorAll('canvas,svg,iframe,[class],[id]').forEach(function(el){
      var tag=el.tagName.toLowerCase(), cl=(typeof el.className==='string'?el.className:(el.className&&el.className.baseVal)||'');
      var ident=(el.id+' '+cl).toLowerCase(), r=el.getBoundingClientRect();
      if(r.width<140||r.height<90)return;
      if(tag==='canvas'||tag==='svg'||tag==='iframe'){
        add(el,tag==='canvas'?10:tag==='svg'?8:5);
        var p=el.parentElement;
        for(var k=0;p&&k<4&&p!==document.body;k++,p=p.parentElement)add(p,7-k);
      }
      if(/chart|candle|kline|tradingview|highcharts|echarts|plot|graph|tv-lightweight|market-chart/.test(ident))add(el,9);
    });
    candidates=Array.from(map.values()).sort(function(a,b){
      return (b.weight*1000000+b.can*100000+b.svg*50000+Math.min(b.w*b.h,800000))-
             (a.weight*1000000+a.can*100000+a.svg*50000+Math.min(a.w*a.h,800000));
    }).slice(0,12);
    render();
  }
  function render(){
    if(!panel)return;
    panel.innerHTML='';
    var title=document.createElement('div');title.textContent='CHẨN ĐOÁN BIỂU ĐỒ · '+(window.__lamboDiagBrokerName||'SÀN');
    style(title,{fontWeight:'800',fontSize:'15px',padding:'8px 4px',color:'#fff'});
    panel.appendChild(title);
    var note=document.createElement('div');note.textContent='Chỉ liệt kê vùng nghi là biểu đồ. Chưa ẩn hay sửa thành phần nào.';
    style(note,{fontSize:'12px',color:'#ffe08a',padding:'3px 4px 8px'});
    panel.appendChild(note);
    if(!candidates.length){var none=document.createElement('div');none.textContent='Chưa tìm thấy vùng phù hợp. Hãy chắc chắn đã đăng nhập và biểu đồ đang hiển thị.';panel.appendChild(none);return;}
    candidates.forEach(function(d,i){
      var row=document.createElement('button');
      row.type='button';
      row.textContent=(i+1)+'. '+d.tag+d.id+' · '+d.w+'×'+d.h+' · canvas '+d.can+' · svg '+d.svg+' · '+short(d.cls,45);
      style(row,{display:'block',width:'100%',textAlign:'left',padding:'8px',margin:'4px 0',border:'1px solid #54708f',borderRadius:'7px',background:'#17243a',color:'#fff',fontSize:'12px',whiteSpace:'normal'});
      row.addEventListener('click',function(){
        removeHighlight();
        d.el.setAttribute('data-lambo-diag-old-outline',d.el.style.outline||'');
        d.el.setAttribute('data-lambo-diag-old-offset',d.el.style.outlineOffset||'');
        d.el.setAttribute('data-lambo-diag-selected','1');
        style(d.el,{outline:'4px solid #ffcf33',outlineOffset:'-4px'});
        showClearButton();
        if(panel&&panel.parentNode)panel.parentNode.removeChild(panel);
        panel=null;
      });
      panel.appendChild(row);
    });
    var status=document.createElement('div');status.setAttribute('data-status','1');status.textContent='Chạm từng dòng để viền vàng vùng tương ứng.';
    style(status,{padding:'8px 4px',color:'#aee7ff',fontSize:'12px'});panel.appendChild(status);
  }
  window.lamboDiagnosticMode=function(enabled,brokerName){
    if(!enabled){
      removeHighlight();
      if(panel&&panel.parentNode)panel.parentNode.removeChild(panel);
      if(button&&button.parentNode)button.parentNode.removeChild(button);
      if(clearButton&&clearButton.parentNode)clearButton.parentNode.removeChild(clearButton);
      panel=null;button=null;clearButton=null;return;
    }
    window.__lamboDiagBrokerName=brokerName||'SÀN';
    if(button&&button.parentNode)return;
    button=document.createElement('button');button.id='lamboDiagButton';button.type='button';button.textContent='CHẨN ĐOÁN BIỂU ĐỒ';
    style(button,{position:'fixed',top:'12px',left:'12px',zIndex:'2147483647',padding:'10px 12px',background:'#1769aa',color:'#fff',border:'2px solid #9bdcff',borderRadius:'8px',fontWeight:'800',fontSize:'14px'});
    button.addEventListener('click',function(){
      if(panel){panel.parentNode.removeChild(panel);panel=null;return;}
      panel=document.createElement('div');
      style(panel,{position:'fixed',top:'58px',left:'8px',right:'8px',maxHeight:'68vh',overflowY:'auto',zIndex:'2147483647',padding:'8px',background:'rgba(5,12,27,.97)',border:'2px solid #32bde8',borderRadius:'10px',boxShadow:'0 4px 20px #000'});
      document.body.appendChild(panel);scan();
    });
    document.body.appendChild(button);
  };
})();
