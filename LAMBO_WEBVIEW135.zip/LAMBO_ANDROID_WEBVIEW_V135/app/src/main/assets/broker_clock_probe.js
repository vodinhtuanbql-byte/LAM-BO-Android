(function(){
  if(window.__lamboClockProbeInstalled)return;window.__lamboClockProbeInstalled=true;
  var lastKey='';
  function parse(s){s=String(s||'').trim();var m=s.match(/^(\d{1,2}):(\d{2})$/);if(m)return (+m[1])*60+(+m[2]);if(/^\d{1,2}$/.test(s))return +s;return -1;}
  function visible(el){if(!el||!el.getBoundingClientRect)return false;var r=el.getBoundingClientRect(),c=getComputedStyle(el);return r.width>0&&r.height>0&&c.display!=='none'&&c.visibility!=='hidden'&&+c.opacity!==0;}
  function detectPhase(){
    // Chỉ dùng nhãn trạng thái hiển thị thực sự trên trang sàn; không suy đoán từ số giây.
    var nodes=document.querySelectorAll('button,[role="button"],span,div,p,strong,b,label');
    var entry=0,result=0,seen=[];
    for(var i=0;i<nodes.length;i++){var el=nodes[i];if(!visible(el)||el.children.length>2)continue;var t=String(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();if(!t||t.length>90||seen.indexOf(t)>=0)continue;seen.push(t);
      if(/(hãy đặt lệnh|đặt lệnh ngay|thời gian đặt lệnh|place (your )?(trade|order)|open for trading|trading open|buy\s*\/\s*sell)/i.test(t))entry++;
      if(/(chờ kết quả|đang chờ kết quả|thời gian kết quả|kết quả giao dịch|trade result|waiting for result|result time|trade closed|settlement|expiry)/i.test(t))result++;
    }
    if(entry>0&&result===0)return 'ENTRY';if(result>0&&entry===0)return 'RESULT';return 'UNKNOWN';
  }
  function read(){var candidates=[];
    document.querySelectorAll('.time,[class*="countdown" i],[class*="timer" i],[class*="remain" i],[class*="clock" i]').forEach(function(el){if(!visible(el)||el.children.length>0)return;var n=parse(el.textContent);if(n>=0&&n<=3600)candidates.push({n:n,score:el.matches('span.time')?100:50});});
    if(!candidates.length)document.querySelectorAll('span,div,strong,b').forEach(function(el){if(!visible(el)||el.children.length>0)return;var n=parse(el.textContent);if(n>=0&&n<=3600&&/^\d{1,2}:\d{2}$/.test(String(el.textContent||'').trim()))candidates.push({n:n,score:10});});
    if(!candidates.length)return;candidates.sort(function(a,b){return b.score-a.score;});
    var n=candidates[0].n,phase=detectPhase(),key=n+'|'+phase;
    if(key!==lastKey||!window.__lamboClockLastAt||Date.now()-window.__lamboClockLastAt>=700){lastKey=key;window.__lamboClockLastAt=Date.now();try{if(window.Android&&typeof Android.reportBrokerClock==='function')Android.reportBrokerClock(n,phase);}catch(e){}}
  }
  read();setInterval(read,250);var mo=new MutationObserver(read);function start(){if(document.documentElement)mo.observe(document.documentElement,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class','disabled','aria-label']});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();