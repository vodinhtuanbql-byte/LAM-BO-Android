
(function(){
  if(window.__lamboChartFocusInstalled) return;
  window.__lamboChartFocusInstalled=true;
  window.__lamboChartFocusActive=false;
  function restore(){
    document.querySelectorAll('[data-lambo-focus-hidden="1"]').forEach(function(el){
      el.style.display=el.getAttribute('data-lambo-old-display')||'';
      el.removeAttribute('data-lambo-focus-hidden');
      el.removeAttribute('data-lambo-old-display');
    });
    document.querySelectorAll('[data-lambo-focus-target="1"]').forEach(function(el){
      el.style.position=el.getAttribute('data-lambo-old-position')||'';
      el.style.left=el.getAttribute('data-lambo-old-left')||'';
      el.style.top=el.getAttribute('data-lambo-old-top')||'';
      el.style.width=el.getAttribute('data-lambo-old-width')||'';
      el.style.height=el.getAttribute('data-lambo-old-height')||'';
      el.style.zIndex=el.getAttribute('data-lambo-old-z')||'';
      el.style.background=el.getAttribute('data-lambo-old-bg')||'';
      ['position','left','top','width','height','zIndex','background'].forEach(function(k){
        el.removeAttribute('data-lambo-old-'+({zIndex:'z',background:'bg'}[k]||k.toLowerCase()));
      });
      el.removeAttribute('data-lambo-focus-target');
    });
    document.documentElement.style.overflow='';
    if(document.body) document.body.style.overflow='';
  }
  function hide(el){
    if(!el || el===document.body || el===document.documentElement) return;
    if(!el.hasAttribute('data-lambo-focus-hidden')){
      el.setAttribute('data-lambo-old-display',el.style.display||'');
      el.setAttribute('data-lambo-focus-hidden','1');
    }
    el.style.setProperty('display','none','important');
  }
  function focus(){
    if(!window.__lamboChartFocusActive) return;
    if(document.querySelector('input[type=password],form[action*="login" i]')) return;
    var nodes=[].slice.call(document.querySelectorAll('canvas'));
    nodes=nodes.filter(function(n){
      var r=n.getBoundingClientRect(),cs=getComputedStyle(n);
      return r.width>100 && r.height>80 && cs.display!=='none' && cs.visibility!=='hidden';
    });
    if(!nodes.length){
      nodes=[].slice.call(document.querySelectorAll('svg')).filter(function(n){
        var r=n.getBoundingClientRect(),cs=getComputedStyle(n);
        return r.width>180 && r.height>120 && cs.display!=='none' && cs.visibility!=='hidden';
      });
    }
    if(!nodes.length) return;
    var best=null, bestScore=-Infinity;
    nodes.forEach(function(node){
      var el=node;
      for(var depth=0;el && depth<7 && el!==document.body;depth++,el=el.parentElement){
        var r=el.getBoundingClientRect();
        if(r.width<180 || r.height<120) continue;
        var count=el.querySelectorAll('canvas').length || 1;
        var area=r.width*r.height;
        var score=(count*1000000)-Math.min(area,2000000);
        if(score>bestScore){best=el;bestScore=score;}
        if(count>1) break;
      }
    });
    if(!best) return;
    var br=best.getBoundingClientRect();
    if(br.width<180 || br.height<120) return;
    var parent=best.parentElement;
    if(!parent) return;
    Array.prototype.forEach.call(parent.children,function(sib){if(sib!==best)hide(sib);});
    var ancestor=parent;
    for(var level=0;ancestor && ancestor!==document.body && level<5;level++,ancestor=ancestor.parentElement){
      Array.prototype.forEach.call(ancestor.children,function(sib){if(sib!==best && !sib.contains(best))hide(sib);});
    }
    if(!best.hasAttribute('data-lambo-focus-target')){
      best.setAttribute('data-lambo-old-position',best.style.position||'');
      best.setAttribute('data-lambo-old-left',best.style.left||'');
      best.setAttribute('data-lambo-old-top',best.style.top||'');
      best.setAttribute('data-lambo-old-width',best.style.width||'');
      best.setAttribute('data-lambo-old-height',best.style.height||'');
      best.setAttribute('data-lambo-old-z',best.style.zIndex||'');
      best.setAttribute('data-lambo-old-bg',best.style.background||'');
      best.setAttribute('data-lambo-focus-target','1');
    }
    best.style.setProperty('position','fixed','important');
    best.style.setProperty('left','0','important');
    best.style.setProperty('top','0','important');
    best.style.setProperty('width','100vw','important');
    best.style.setProperty('height','100vh','important');
    best.style.setProperty('z-index','2147483646','important');
    best.style.setProperty('background','#070d1c','important');
    document.documentElement.style.overflow='hidden';
    if(document.body) document.body.style.overflow='hidden';
  }
  window.lamboSetChartOnly=function(enabled){
    window.__lamboChartFocusActive=!!enabled;
    if(!enabled){restore();return;}
    restore();
    setTimeout(focus,700);
    setTimeout(focus,1800);
    setTimeout(focus,3500);
  };
  var mo=new MutationObserver(function(){if(window.__lamboChartFocusActive) setTimeout(focus,300);});
  mo.observe(document.documentElement,{childList:true,subtree:true});
})();
