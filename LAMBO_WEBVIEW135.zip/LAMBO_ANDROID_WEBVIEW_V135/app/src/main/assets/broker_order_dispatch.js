(function(){
 if(window.LamboOrder)return;
 const visible=e=>{if(!e||!e.getBoundingClientRect)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&Number(s.opacity||1)>0};
 const txt=e=>(e.innerText||e.textContent||e.getAttribute("aria-label")||e.value||"").replace(/\s+/g," ").trim();
 function report(id,status,detail){try{if(window.Android&&Android.reportOrderStatus)Android.reportOrderStatus(id,status,detail||"")}catch(e){}}
 window.LamboOrder={dispatch:function(side,amount,accountMode,id){
  try{
   if(!["MUA","BÁN"].includes(side)){report(id,"CHƯA GỬI","Chiều lệnh không hợp lệ");return;}
   const body=(document.body?document.body.innerText:"");
   const activeMode=[...document.querySelectorAll('[aria-pressed="true"],[aria-selected="true"],.active,.selected,[data-state="active"]')]
    .filter(visible).map(txt).join(" ");
   const modeText=(activeMode+" "+body.slice(0,5000)).toLowerCase();
   const hasDemo=/demo|thử nghiệm/.test(modeText);
   const hasLive=/live|real|thực|tiền thật/.test(modeText);
   if(accountMode==="DEMO" && (!hasDemo || hasLive && !/demo|thử nghiệm/.test(activeMode.toLowerCase()))){
    report(id,"CHƯA GỬI","Không xác minh chắc chắn tài khoản DEMO đang được chọn");return;
   }
   if(accountMode==="LIVE" && (!hasLive || hasDemo && !/live|real|thực|tiền thật/.test(activeMode.toLowerCase()))){
    report(id,"CHƯA GỬI","Không xác minh chắc chắn tài khoản THỰC đang được chọn");return;
   }
   if(!/chờ đặt lệnh|đặt lệnh|trading|place your trade|buy now|sell now/i.test(body)){report(id,"CHƯA GỬI","Không xác minh được trạng thái cho phép đặt lệnh");return;}
   const inputs=[...document.querySelectorAll('input:not([type=password]):not([type=hidden]),textarea')]
    .filter(e=>visible(e)&&!e.disabled&&!e.readOnly)
    .filter(e=>/amount|stake|bet|wager|tiền|cược|số tiền/i.test([e.name,e.id,e.placeholder,e.getAttribute("aria-label"),e.getAttribute("data-testid")].join(" ")));
   if(inputs.length!==1){report(id,"CHƯA GỬI","Không tìm được duy nhất một ô tiền cược rõ ràng");return;}
   const input=inputs[0],v=String(amount);
   const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value")?.set;
   if(setter&&input instanceof HTMLInputElement)setter.call(input,v);else input.value=v;
   input.dispatchEvent(new Event("input",{bubbles:true}));
   input.dispatchEvent(new Event("change",{bubbles:true}));
   input.dispatchEvent(new Event("blur",{bubbles:true}));
   if(String(input.value).replace(/[^\d.]/g,"")!==v.replace(/[^\d.]/g,"")){report(id,"CHƯA GỬI","Sàn không xác nhận giá trị tiền cược");return;}
   const wanted=side==="MUA"?/^(mua|buy|call|↑)$/i:/^(bán|ban|sell|put|↓)$/i;
   const buttons=[...document.querySelectorAll('button,[role=button],input[type=button],input[type=submit]')]
    .filter(e=>visible(e)&&!e.disabled&&wanted.test(txt(e)));
   if(buttons.length!==1){report(id,"CHƯA GỬI","Không tìm được duy nhất một nút "+side);return;}
   buttons[0].click();
   report(id,"ĐÃ NHẤN NÚT · CHƯA XÁC NHẬN","Đã gọi nút gốc của sàn; cần xác minh phản hồi/ lịch sử lệnh");
  }catch(e){report(id,"LỖI","Không thể thao tác: "+String(e).slice(0,120));}
 }};
})();