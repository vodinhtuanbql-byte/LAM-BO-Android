(function(){
 if(window.LamboOrder)return;
 const visible=e=>{if(!e||!e.getBoundingClientRect)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&Number(s.opacity||1)>0;};
 const txt=e=>(e.innerText||e.textContent||e.getAttribute("aria-label")||e.value||"").replace(/\s+/g," ").trim();
 function report(id,status,detail){try{if(window.Android&&Android.reportOrderStatus)Android.reportOrderStatus(id,status,detail||"");}catch(e){}}
 function activeAccount(){
  const nodes=[...document.querySelectorAll('[aria-pressed="true"],[aria-selected="true"],[data-state="active"],.active,.selected,[class*="active" i],[class*="selected" i]')].filter(visible);
  const labels=[...new Set(nodes.map(txt).filter(t=>t&&t.length<=60))];
  const relevant=labels.filter(t=>/\bdemo\b|thử nghiệm|\blive\b|\breal\b|tiền thật/i.test(t));
  return {labels:relevant, text:relevant.join(" | ").toLowerCase()};
 }
 window.LamboOrder={dispatch:function(side,amount,accountMode,id){
  try{
   if(!["MUA","BÁN"].includes(side)){report(id,"CHƯA GỬI","Chiều lệnh không hợp lệ");return;}
   const mode=activeAccount();
   const demo=/\bdemo\b|thử nghiệm/.test(mode.text), live=/\blive\b|\breal\b|tiền thật/.test(mode.text);
   if((accountMode==="DEMO"&&(!demo||live))||(accountMode==="LIVE"&&(!live||demo))){
    report(id,"CHƯA GỬI","Không xác minh được nút tài khoản đang chọn. Các nhãn đang hoạt động: "+(mode.labels.join(" / ")||"không đọc được"));return;
   }
   const body=document.body?document.body.innerText:"";
   if(!/chờ đặt lệnh|đặt lệnh|trading|place your trade|buy now|sell now/i.test(body)){report(id,"CHƯA GỬI","Không tìm thấy chỉ báo phiên đang cho phép đặt lệnh trên trang sàn");return;}
   const inputs=[...document.querySelectorAll('input:not([type=password]):not([type=hidden]),textarea')].filter(e=>visible(e)&&!e.disabled&&!e.readOnly);
   const candidates=inputs.filter(e=>/amount|stake|bet|wager|tiền|cược|số tiền/i.test([e.name,e.id,e.placeholder,e.getAttribute("aria-label"),e.getAttribute("data-testid")].join(" ")));
   if(candidates.length!==1){report(id,"CHƯA GỬI","Ô tiền cược không xác định duy nhất (tìm thấy "+candidates.length+" ô phù hợp)");return;}
   const input=candidates[0],v=String(amount);
   const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value")?.set;
   if(setter&&input instanceof HTMLInputElement)setter.call(input,v);else input.value=v;
   input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}));input.dispatchEvent(new Event("blur",{bubbles:true}));
   if(String(input.value).replace(/[^\d.]/g,"")!==v.replace(/[^\d.]/g,"")){report(id,"CHƯA GỬI","Giá trị tiền cược trên trang không khớp số tiền LAMBO yêu cầu");return;}
   const wanted=side==="MUA"?/^(mua|buy|call|↑)$/i:/^(bán|ban|sell|put|↓)$/i;
   const buttons=[...document.querySelectorAll('button,[role=button],input[type=button],input[type=submit]')].filter(e=>visible(e)&&!e.disabled&&wanted.test(txt(e)));
   if(buttons.length!==1){report(id,"CHƯA GỬI","Không tìm thấy duy nhất nút "+side+" (tìm thấy "+buttons.length+")");return;}
   buttons[0].click();
   report(id,"ĐÃ NHẤN NÚT · CHƯA XÁC NHẬN","Đã gọi nút trên trang sàn; chưa có bằng chứng sàn ghi nhận lệnh");
  }catch(e){report(id,"LỖI","Lỗi bộ điều khiển: "+String(e).slice(0,140));}
 }};
})();
