(function(){
  if(window.__lamboColtraMiniFilterInstalled) return;
  window.__lamboColtraMiniFilterInstalled=true;
  window.__lamboColtraMiniMode=false;
  function apply(){
    var zone=document.querySelector('#highchart_container');
    if(!zone) return;
    var area=zone.parentElement;
    if(!area || !area.classList.contains('chart-area-mobile')) return;
    var bottom=area.querySelector(':scope > .fixed-bottom-zone');
    if(bottom){
      if(window.__lamboColtraMiniMode){
        if(!bottom.hasAttribute('data-lambo-coltra-display')) bottom.setAttribute('data-lambo-coltra-display',bottom.style.display||'');
        bottom.style.setProperty('display','none','important');
      }else if(bottom.hasAttribute('data-lambo-coltra-display')){
        bottom.style.display=bottom.getAttribute('data-lambo-coltra-display');
        bottom.removeAttribute('data-lambo-coltra-display');
      }
    }
  }
  window.lamboSetColtraMiniMode=function(enabled){
    window.__lamboColtraMiniMode=!!enabled;
    apply();
    setTimeout(apply,250);
    setTimeout(apply,900);
  };
  var observer=new MutationObserver(function(){apply();});
  function start(){if(document.documentElement) observer.observe(document.documentElement,{childList:true,subtree:true});apply();}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true}); else start();
})();
