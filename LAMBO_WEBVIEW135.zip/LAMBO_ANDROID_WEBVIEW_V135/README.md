# LAM BO V1.42 – Three independent broker WebViews

- Preserves the existing LAM BO HTML layout and Binance/demo sections.
- Creates one independent Android WebView for each configured platform: LUXWIN, COLTRA1, FIAURA1.
- Places each native WebView over its matching mini-chart slot using live layout coordinates from the HTML page.
- Keeps separate WebView navigation, DOM storage and cookies per platform.
- Broker buttons request the corresponding WebView; a failed page does not replace the other two.

Important: this is a WebView display integration only. It does not authenticate accounts on behalf of the user, read credentials, or submit real broker orders. Each site may block embedding, require its own login, or render poorly in a narrow card. Three simultaneous WebViews increase memory use; stability must be tested on the target phone.


## V1.43 WebView network diagnostics
- Preserves the existing three-panel layout and three independent broker WebViews.
- Starts broker pages 900 ms apart to reduce startup spikes.
- Removes only the Android WebView marker from the device's actual user-agent string.
- Enables in-app handling for broker popup windows.
- Reports exact WebView network error codes, HTTP status errors, and HTTPS certificate errors.
- HTTPS certificate validation remains enabled; certificate errors are never bypassed.
- Broker websites may still block embedded WebViews or require browser-only features; compatibility is not guaranteed.


## V1.48 rollback stability
- Based on the earlier multi-WebView source tree.
- Restores creation of all three broker WebViews at application startup.
- Keeps the original `index.html` unchanged.
- Removes the later main-WebView renderer auto-recreation and startup fallback logic by reverting to the earlier Activity implementation.
- Staggers broker navigation starts by 2.5 seconds per broker to reduce simultaneous startup load.
- Version code/name: 148 / 1.48-rollback-stability.
