# LAM BO Android WebView V1.35

This project wraps the existing LAM BO HTML in an Android app. Broker buttons open the selected broker in a second in-app Android WebView, then Android Back returns to LAM BO.

The uploaded HTML's simulation logic, localStorage keys, risk controls, reports, and existing trade notification text are preserved. Only broker-page navigation was changed from iframe loading to the Android WebView bridge.

## Build on GitHub
Push the project contents to a GitHub repository's `main` branch. Open Actions, run **Build LAM BO Android WebView APK**, then download the `LAM-BO-Android-WebView-V135-debug` artifact from the completed run.

## Limits
- An in-app WebView is not proof of broker authorization or account integration.
- This build does not read credentials, cookies, balances, trade history, or send broker orders.
- A broker may block WebView or require a supported browser; test on the phone.
- LAM BO's BUY/SELL remains simulation-only.


## V1.38 – giảm tải WebView
- Khi mở một sàn, LAM BO giải phóng WebView giao diện trước khi khởi chạy màn hình WebView của sàn.
- Khi quay lại, giao diện LAM BO được tạo lại; dữ liệu lưu bằng localStorage vẫn nằm trong WebView storage của ứng dụng.
- Chỉ có một WebView hoạt động tại một thời điểm để giảm áp lực bộ nhớ.


## V1.39 – kiểm tra lệnh mở sàn
- Hiển thị Toast khi Android nhận lệnh mở sàn từ JavaScript.
- Ghi log tag `LAMBO` để phân biệt lỗi cầu nối và lỗi khởi chạy BrokerActivity.
- Nếu BrokerActivity không khởi chạy được, hiện thông báo lỗi và khôi phục giao diện chính.
- Giữ nguyên mô hình một WebView hoạt động tại một thời điểm.


## V1.40 – bridge diagnostic follow-up
- Makes the JavaScript bridge class public for WebView reflection.
- Shows an on-screen log/status message immediately when the Mở sàn button is tapped.
- Logs bridge invocation and shows a native Toast when Android receives the request.
- Keeps broker integration unverified; no credentials or session data are extracted.


V1.46: Ba website LUXWIN, COLTRA1, FIAURA1 được mở riêng ở màn hình WebView toàn màn hình để thao tác đăng nhập thuận tiện trên điện thoại. Biểu đồ DEMO Binance vẫn độc lập. Không tự động đăng nhập, đọc số dư hoặc gửi lệnh thật.


## V1.72 - broker countdown probe
- Each broker WebView reports a visible countdown candidate to the Android bridge.
- The central timer chooses the smallest fresh remaining time among the three broker countdowns.
- The central label shows the selected broker and changes to “HÃY ĐẶT LỆNH” only in the final 4 seconds.
- If no fresh broker countdown is readable, the central display shows “--” and waits; it does not fabricate a countdown.
- Countdown selectors are heuristic except COLTRA1’s observed `span.time`; verify each broker in the installed APK before relying on the result.
- The demo trade engine remains simulated and does not submit orders to broker sites.


## V1.73 - Binance volume confirmation (preview)
- Binance aggregate trades (`aggTrade`) are used to calculate taker-buy and taker-sell BTC volume over a rolling 30-second window. Buyer-maker trades are classified as seller-aggressor volume; non-maker buyer trades as buyer-aggressor volume.
- BUY/SELL analysis now requires EMA/RSI agreement across the existing 30-second, 1-minute and 5-minute samples, PSAR direction on Binance 1-minute candles, and at least 10% dominance of matching taker volume. Otherwise it displays WAIT.
- Volume feed freshness is checked separately; stale/missing volume blocks a directional alert.
- IMPORTANT: the current broker probe reads a countdown number, but does not yet identify whether each broker is in its 30-second order-entry phase or 30-second result phase. V1.73 therefore blocks BUY/SELL alerts until the broker phase is reliably identified. The displayed broker countdown is informational only; do not use this preview for real-money trading.
- BUY/SELL remains simulation-only and is not submitted to broker websites.


V1.74: broker countdown phase-aware. The central timer and BUY/SELL reminder are enabled only when a visible broker-native phase label identifies ENTRY or RESULT. If no explicit phase label is found, display -- / wait for phase verification; never infer phase from countdown digits alone. Binance aggTrade volume is used as a confirmation filter; all order controls remain demo-only.
