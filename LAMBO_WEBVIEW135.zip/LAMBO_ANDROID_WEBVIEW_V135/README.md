# LAM BO Android WebView V1.35

This project wraps the existing LAM BO HTML in an Android app. Broker buttons open the selected broker in a second in-app Android WebView, then Android Back returns to LAM BO.

The uploaded HTML's simulation logic, localStorage keys, risk controls, reports, and existing trade notification text are preserved. Only broker-page navigation was changed from iframe loading to the Android WebView bridge.

## Build on GitHub
Push the project contents to a GitHub repository's `main` branch. Open Actions, run **Build LAM BO Android WebView APK**, then download the `LAM-BO-Android-WebView-V135-debug` artifact from the completed run.

## Limits
- An in-app WebView is not proof of broker authorization or account integration.
- This build does not read credentials, cookies, balances, trade history, or send broker orders.
- A broker may block WebView or require a supported browser; test on the phone.
- LAM BO's BUY/SELL remains simulation-only.


## V1.38 – giảm tải WebView
- Khi mở một sàn, LAM BO giải phóng WebView giao diện trước khi khởi chạy màn hình WebView của sàn.
- Khi quay lại, giao diện LAM BO được tạo lại; dữ liệu lưu bằng localStorage vẫn nằm trong WebView storage của ứng dụng.
- Chỉ có một WebView hoạt động tại một thời điểm để giảm áp lực bộ nhớ.


## V1.39 – kiểm tra lệnh mở sàn
- Hiển thị Toast khi Android nhận lệnh mở sàn từ JavaScript.
- Ghi log tag `LAMBO` để phân biệt lỗi cầu nối và lỗi khởi chạy BrokerActivity.
- Nếu BrokerActivity không khởi chạy được, hiện thông báo lỗi và khôi phục giao diện chính.
- Giữ nguyên mô hình một WebView hoạt động tại một thời điểm.


## V1.40 – bridge diagnostic follow-up
- Makes the JavaScript bridge class public for WebView reflection.
- Shows an on-screen log/status message immediately when the Mở sàn button is tapped.
- Logs bridge invocation and shows a native Toast when Android receives the request.
- Keeps broker integration unverified; no credentials or session data are extracted.


V1.46: Ba website LUXWIN, COLTRA1, FIAURA1 được mở riêng ở màn hình WebView toàn màn hình để thao tác đăng nhập thuận tiện trên điện thoại. Biểu đồ DEMO Binance vẫn độc lập. Không tự động đăng nhập, đọc số dư hoặc gửi lệnh thật.


## V1.72 - broker countdown probe
- Each broker WebView reports a visible countdown candidate to the Android bridge.
- The central timer chooses the smallest fresh remaining time among the three broker countdowns.
- The central label shows the selected broker and changes to “HÃY ĐẶT LỆNH” only in the final 4 seconds.
- If no fresh broker countdown is readable, the central display shows “--” and waits; it does not fabricate a countdown.
- Countdown selectors are heuristic except COLTRA1’s observed `span.time`; verify each broker in the installed APK before relying on the result.
- The demo trade engine remains simulated and does not submit orders to broker sites.


## V1.73 - Binance volume confirmation (preview)
- Binance aggregate trades (`aggTrade`) are used to calculate taker-buy and taker-sell BTC volume over a rolling 30-second window. Buyer-maker trades are classified as seller-aggressor volume; non-maker buyer trades as buyer-aggressor volume.
- BUY/SELL analysis now requires EMA/RSI agreement across the existing 30-second, 1-minute and 5-minute samples, PSAR direction on Binance 1-minute candles, and at least 10% dominance of matching taker volume. Otherwise it displays WAIT.
- Volume feed freshness is checked separately; stale/missing volume blocks a directional alert.
- IMPORTANT: the current broker probe reads a countdown number, but does not yet identify whether each broker is in its 30-second order-entry phase or 30-second result phase. V1.73 therefore blocks BUY/SELL alerts until the broker phase is reliably identified. The displayed broker countdown is informational only; do not use this preview for real-money trading.
- BUY/SELL remains simulation-only and is not submitted to broker websites.


V1.74: broker countdown phase-aware. The central timer and BUY/SELL reminder are enabled only when a visible broker-native phase label identifies ENTRY or RESULT. If no explicit phase label is found, display -- / wait for phase verification; never infer phase from countdown digits alone. Binance aggTrade volume is used as a confirmation filter; all order controls remain demo-only.


## V1.77 – nhiều lệnh trong pha ENTRY
- Bỏ giới hạn một lệnh cho mỗi chu kỳ ENTRY. Người dùng có thể nhấn MUA/BÁN nhiều lần trong suốt pha ENTRY đã được xác minh từ đồng hồ/trạng thái sàn.
- Mỗi lần nhấn tạo một bản ghi lệnh mô phỏng riêng cho từng sàn được chọn.
- Không dùng bộ đếm chu kỳ nội bộ của điện thoại để chặn lệnh; trạng thái ENTRY/RESULT từ probe sàn là điều kiện thời gian.
- Vẫn kiểm tra số dư mô phỏng, mức cược hợp lệ và giới hạn lỗ ngày đã cài. Không giới hạn số lần nhấn, nhưng không cho chi vượt số dư.
- Chế độ DEMO hiện vẫn là mô phỏng nội bộ, chưa lấy số dư Demo từ website BO. Chế độ LIVE chưa có kết nối số dư thực. Không đọc được số dư tài khoản từ các sàn nếu chưa xác định selector/nguồn dữ liệu được sàn cho phép; các ô số dư thực giữ dấu —, không giả lập.
- Không gửi lệnh đến LUXWIN, COLTRA1 hoặc FIAURA1.

## V1.78 - Broker visible balance reading
- Each broker WebView injects `broker_balance_probe.js` after page load.
- The probe reads only visible balance/wallet DOM elements and reports a value only when the account type (DEMO or LIVE) can be distinguished from the visible page context.
- Numeric zero is valid and is rendered as `0.00` (not treated as missing).
- Demo and Live balance cards are separate for LUXWIN, COLTRA1, and FIAURA1.
- If the page does not expose a clearly identifiable balance field/account mode, the display remains `—`; the probe does not invent or substitute a value.
- This is DOM observation, not an official broker API. Site markup changes may prevent detection; verify each broker's displayed balance against its own account page before relying on it.
- The internal practice simulator remains separate and is explicitly labelled as not being the broker Demo balance. No real-money orders are sent by this balance reader.


## LAMBO broker order controller (experimental)
- The central MUA/BÁN action now sends a Demo-only dispatch request to each selected broker WebView.
- Each broker WebView uses a fail-closed DOM matcher: it requires visible Demo/trading context, exactly one clearly labelled stake input, and exactly one visible enabled native direction button.
- Ambiguous controls are rejected rather than guessed. A click is reported as `ĐÃ NHẤN NÚT · CHƯA XÁC NHẬN`; this is NOT broker acceptance.
- Real-money/Live order dispatch is intentionally blocked. Broker-specific acceptance and order-history verification still require testing against each logged-in Demo site.


## Demo-only central broker control
The central MUA/BÁN buttons dispatch to selected broker WebViews only while LAMBO account mode is DEMO. Live mode is blocked in the app code. The broker-side dispatcher fails closed unless it finds a visible, editable, clearly labelled stake input and exactly one visible enabled native direction button. It reports a native button click as not-yet-confirmed; it does not claim broker acceptance without a verified broker response.


## Account mode handling update
The central dispatcher now passes the selected account mode (DEMO or LIVE) through the Android bridge. Broker-side code fails closed unless the requested mode can be identified from the page's active account controls/text. This change removes the app-level hardcoded Demo-only guard, but does not establish broker-specific selectors or prove Live order acceptance. Do not treat a button click as an accepted trade.


## V1.81 audit fix
- Central nearest-broker clock is display-only and no longer globally disables MUA/BÁN.
- Android now checks the selected broker's own fresh clock state (`ENTRY`, timestamp no older than 1.8 seconds) before dispatching.
- Each broker outside a verified entry phase is rejected independently; other selected brokers can still receive an order if their own phase is ENTRY.
- Order status callbacks are marshalled to the UI thread.
- App version set to 1.81 (versionCode 181).
- This does not yet verify broker-specific stake/button selectors or broker acceptance; no claim of successful trade execution.


## V1.82 audit update
- Trạng thái bị chặn trước khi thao tác được ghi là `CHƯA GỬI`, không còn dùng nhãn `SÀN TỪ CHỐI` gây hiểu nhầm.
- Gửi trạng thái `ĐANG GỬI` trước khi gọi bộ điều khiển trong WebView.
- `ĐÃ NHẤN NÚT · CHƯA XÁC NHẬN` vẫn không được coi là sàn đã nhận lệnh.


## V1.83 – sửa trạng thái điều khiển lệnh
- Đồng bộ nhãn giao diện, versionCode/versionName và tên artifact GitHub Actions lên 1.83.
- Tăng ngưỡng tươi của đồng hồ riêng từng WebView từ 1,8 lên 2,5 giây; pha vẫn phải được đọc trực tiếp từ từng sàn.
- Không còn dò ô cược bằng cách chọn một ô nhập bất kỳ khi không thấy nhãn nhận diện; chỉ thao tác khi tìm được duy nhất ô cược có định danh phù hợp.
- Xác minh Demo/Live chỉ dựa trên thành phần giao diện đang được đánh dấu chọn, không dựa vào việc chữ Demo/Live xuất hiện đâu đó trong toàn trang.
- Báo rõ lý do chưa gửi khi không xác minh được tài khoản, pha, ô cược hoặc nút lệnh.
- Trạng thái sau khi nhấn nút vẫn là “ĐÃ NHẤN NÚT · CHƯA XÁC NHẬN”; không giả lập xác nhận nhận lệnh.

**Giới hạn kiểm thử:** mã nguồn/JavaScript và ZIP được kiểm tra tĩnh. Chưa có DOM thực tế của tài khoản COLTRA1/FIAURA1/LUXWIN để xác nhận selector, chưa build APK trong môi trường này và chưa xác minh giao dịch trên sàn.
