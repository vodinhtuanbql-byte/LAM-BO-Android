# LAM BO Android WebView V1.35

This project wraps the existing LAM BO HTML in an Android app. Broker buttons open the selected broker in a second in-app Android WebView, then Android Back returns to LAM BO.

The uploaded HTML's simulation logic, localStorage keys, risk controls, reports, and existing trade notification text are preserved. Only broker-page navigation was changed from iframe loading to the Android WebView bridge.

## Build on GitHub
Push the project contents to a GitHub repository's `main` branch. Open Actions, run **Build LAM BO Android WebView APK**, then download the `LAM-BO-Android-WebView-V135-debug` artifact from the completed run.

## Limits
- An in-app WebView is not proof of broker authorization or account integration.
- This build does not read credentials, cookies, balances, trade history, or send broker orders.
- A broker may block WebView or require a supported browser; test on the phone.
- LAM BO's BUY/SELL remains simulation-only.


## V1.38 – giảm tải WebView
- Khi mở một sàn, LAM BO giải phóng WebView giao diện trước khi khởi chạy màn hình WebView của sàn.
- Khi quay lại, giao diện LAM BO được tạo lại; dữ liệu lưu bằng localStorage vẫn nằm trong WebView storage của ứng dụng.
- Chỉ có một WebView hoạt động tại một thời điểm để giảm áp lực bộ nhớ.
