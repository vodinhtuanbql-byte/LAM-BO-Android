# LAM BO Android WebView — V1.48

- Base: last-known multi-WebView source tree.
- Keeps the existing `index.html` unchanged.
- Creates three broker WebViews at startup.
- Staggers broker page loads by 3.5 seconds.
- Handles renderer termination for the main UI WebView.
- Recreates the local UI at most once after a renderer exit.
- Does not automatically reload broker pages after renderer termination, to avoid a repeated crash loop.

Build: `gradle --no-daemon :app:assembleDebug` (Android SDK 35, JDK 17, Gradle 8.9).

This source archive has not been built or device-tested in this environment.
