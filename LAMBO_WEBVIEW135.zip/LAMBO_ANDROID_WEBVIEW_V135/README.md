LAM BO Android WebView - V1.46 Lazy WebViews

LAM BO Android WebView - V1.45 Renderer Recovery

# LAM BO V1.42 – Three independent broker WebViews

- Preserves the existing LAM BO HTML layout and Binance/demo sections.
- Creates one independent Android WebView for each configured platform: LUXWIN, COLTRA1, FIAURA1.
- Places each native WebView over its matching mini-chart slot using live layout coordinates from the HTML page.
- Keeps separate WebView navigation, DOM storage and cookies per platform.
- Broker buttons request the corresponding WebView; a failed page does not replace the other two.

Important: this is a WebView display integration only. It does not authenticate accounts on behalf of the user, read credentials, or submit real broker orders. Each site may block embedding, require its own login, or render poorly in a narrow card. Three simultaneous WebViews increase memory use; stability must be tested on the target phone.


## V1.43 WebView network diagnostics
- Preserves the existing three-panel layout and three independent broker WebViews.
- Starts broker pages 900 ms apart to reduce startup spikes.
- Removes only the Android WebView marker from the device's actual user-agent string.
- Enables in-app handling for broker popup windows.
- Reports exact WebView network error codes, HTTP status errors, and HTTPS certificate errors.
- HTTPS certificate validation remains enabled; certificate errors are never bypassed.
- Broker websites may still block embedded WebViews or require browser-only features; compatibility is not guaranteed.


V1.45 changes: removes forced hardware layer on the main WebView, recreates the main UI WebView if Android terminates its renderer, and spaces broker WebView startup by 3.5 seconds to reduce startup memory/network pressure. Broker URLs and three-panel layout are unchanged. This is a source-level recovery change; it still requires a GitHub Actions build and on-device verification.


V1.46: Broker WebViews are no longer instantiated during cold start. Each is created on first explicit open request and retained in its existing panel slot. This reduces initial renderer/memory pressure while preserving the three-panel UI. Main-frame local UI load errors display a native-readable diagnostic page. Requires GitHub Actions build and device testing.
