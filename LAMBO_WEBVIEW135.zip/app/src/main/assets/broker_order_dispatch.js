(function(){
 if(window.LamboOrder)return;
 const visible=e=>{if(!e||!e.getBoundingClientRect)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&Number(s.opacity||1)>0;};
 const txt=e=>(e.innerText||e.textContent||e.getAttribute("aria-label")||e.value||"").replace(/\s+/g," ").trim();
 function report(id,status,detail){try{if(window.Android&&Android.reportOrderStatus)Android.reportOrderStatus(id,status,detail||"");}catch(e){}}
 function stop(id,detail){report(id,"CHƯA GỬI",detail);return false;}
 function activeAccount(){
  const nodes=[...document.querySelectorAll('[aria-pressed="true"],[aria-selected="true"],[data-state="active"],.active,.selected,[class*="active" i],[class*="selected" i]')].filter(visible);
  const labels=[...new Set(nodes.map(txt).filter(t=>t&&t.length<=60))];
  const relevant=labels.filter(t=>/\bdemo\b|thử nghiệm|\blive\b|\breal\b|tiền thật/i.test(t));
  return {labels:relevant,text:relevant.join(" | ").toLowerCase()};
 }
 window.LamboOrder={dispatch:function(side,amount,accountMode,id){
  try{
   if(!["MUA","BÁN"].includes(side))return stop(id,"Chiều lệnh không hợp lệ");
   if(!["DEMO","LIVE"].includes(accountMode))return stop(id,"Loại tài khoản không hợp lệ");
   const stake=Number(amount);
   if(!Number.isFinite(stake)||stake<=0||stake>1000000)return stop(id,"Số tiền cược không hợp lệ");
   const mode=activeAccount();
   const demo=/\bdemo\b|thử nghiệm/.test(mode.text),live=/\blive\b|\breal\b|tiền thật/.test(mode.text);
   if((accountMode==="DEMO"&&(!demo||live))||(accountMode==="LIVE"&&(!live||demo)))
    return stop(id,"Không xác minh được tài khoản đang chọn. Nhãn nhận diện: "+(mode.labels.join(" / ")||"không đọc được"));
   // One common BO timer, sourced from COLTRA1 and shared by all three brokers.
   let clockSeconds=-1,clockAt=0,clockPhase="UNKNOWN";
   try{
    if(window.Android){
     clockSeconds=Number(Android.getBrokerTimerSeconds());
     clockAt=Number(Android.getBrokerTimerAt());
     clockPhase=String(Android.getBrokerTimerPhase()||"UNKNOWN");
    }
   }catch(e){}
   if(clockPhase!=="ENTRY"||!Number.isFinite(clockSeconds)||clockSeconds<0||
      !clockAt||Date.now()-clockAt>1800){
    return stop(id,"Đồng hồ BO chung (nguồn COLTRA1) chưa ở pha đặt lệnh hoặc dữ liệu đã cũ");
   }
   const body=document.body?document.body.innerText:"";
   if(!/chờ đặt lệnh|đặt lệnh|trading|place your trade|buy now|sell now/i.test(body))return stop(id,"Không xác minh được trang sàn đang ở pha cho phép đặt lệnh");
   const inputs=[...document.querySelectorAll('input:not([type=password]):not([type=hidden]),textarea,[contenteditable="true"]')].filter(e=>visible(e)&&!e.disabled&&!e.readOnly);
   const fieldMeta=e=>[e.name,e.id,e.placeholder,e.getAttribute("aria-label"),e.getAttribute("data-testid"),e.getAttribute("inputmode")].join(" ").toLowerCase();
   let candidates=inputs.filter(e=>/amount|stake|bet|wager|tiền|cược|số tiền/i.test(fieldMeta(e)));
   // Fallback for broker UIs whose stake box has no semantic label: identify a visible
   // numeric field grouped with +/- controls and a currency/stake context.
   if(candidates.length===0){
    candidates=inputs.filter(e=>{
     const t=(e.value||e.innerText||e.textContent||"").trim();
     if(!/^[\$€£]?\s*\d+(?:[.,]\d+)?\s*$/.test(t))return false;
     const host=e.parentElement&&e.parentElement.parentElement;
     if(!host)return false;
     const context=(host.innerText||host.textContent||"").toLowerCase();
     const controls=[...host.querySelectorAll('button,[role=button],input[type=button]')].filter(visible).map(txt).join(" ");
     return /\$|usdt|usd|amount|stake|bet|wager|cược|tiền/.test(context)&&(/[+−-]/.test(controls)||/\+/.test(context));
    });
   }
   if(candidates.length!==1){
    // Safe, read-only DOM summary to help build a broker-specific adapter on the next pass.
    // Never collect passwords, hidden fields, cookies, tokens, or arbitrary account text.
    const summary=inputs.slice(0,12).map(e=>{
     const type=String(e.type||e.tagName||'').toLowerCase();
     const meta=[e.name,e.id,e.placeholder,e.getAttribute('aria-label'),e.getAttribute('data-testid')].filter(Boolean).join('/').slice(0,70);
     const value=/^(number|text|tel)$/i.test(type)&&/^[\s$€£]*\d+(?:[.,]\d+)?\s*$/.test(String(e.value||''))?String(e.value).slice(0,16):'';
     const host=e.parentElement&&e.parentElement.parentElement;
     const context=host?String(host.innerText||host.textContent||'').replace(/\s+/g,' ').slice(0,65):'';
     return type+'['+meta+']='+value+'{'+context+'}';
    }).join(' ; ').slice(0,145);
    return stop(id,"Không xác định duy nhất ô cược ("+candidates.length+"). Thông tin trường hiển thị: "+(summary||'không có trường phù hợp'));
   }
   const input=candidates[0],v=String(amount);
   input.focus();
   if(input.isContentEditable){input.textContent=v;input.dispatchEvent(new InputEvent("input",{bubbles:true,inputType:"insertText",data:v}));}
   else{
    const proto=input instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
    const setter=Object.getOwnPropertyDescriptor(proto,"value")?.set;
    if(setter)setter.call(input,v);else input.value=v;
    input.dispatchEvent(new Event("input",{bubbles:true}));
    input.dispatchEvent(new Event("change",{bubbles:true}));
   }
   input.dispatchEvent(new Event("blur",{bubbles:true}));
   const readback=String(input.value??input.innerText??input.textContent??"").replace(/[^\d.]/g,"");
   if(readback!==v.replace(/[^\d.]/g,""))return stop(id,"Ô tiền cược trên trang không nhận đúng giá trị "+v+"; giá trị đọc lại: "+readback);
   const wanted=side==="MUA"?/^(mua|buy|call|↑)$/i:/^(bán|ban|sell|put|↓)$/i;
   const buttons=[...document.querySelectorAll('button,[role=button],input[type=button],input[type=submit]')].filter(e=>visible(e)&&!e.disabled&&wanted.test(txt(e)));
   if(buttons.length!==1)return stop(id,"Không tìm thấy duy nhất nút "+side+" (tìm thấy "+buttons.length+")");
   buttons[0].click();
   report(id,"ĐÃ NHẤN NÚT · CHƯA XÁC NHẬN","Đã gọi nút trên trang sàn; chưa có bằng chứng sàn ghi nhận lệnh");
   return true;
  }catch(e){report(id,"LỖI","Lỗi bộ điều khiển: "+String(e).slice(0,140));return false;}
 }};
})();
