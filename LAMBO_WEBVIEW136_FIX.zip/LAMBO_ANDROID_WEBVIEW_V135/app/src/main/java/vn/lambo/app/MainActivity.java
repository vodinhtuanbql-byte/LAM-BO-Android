package vn.lambo.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.widget.FrameLayout;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
    private FrameLayout root;
    private WebView appView, brokerView;
    private boolean brokerVisible = false;
    private boolean brokerPageStarted = false;
    private final String[] brokerUrls = {
        "https://luxwin3.net/",
        "https://coltra1.net/",
        "https://fiaura1.net/"
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        CookieManager.getInstance().setAcceptCookie(true);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5,10,23));

        appView = new WebView(this);
        configure(appView, true);
        appView.addJavascriptInterface(new Bridge(), "Android");
        appView.setWebViewClient(new WebViewClient());
        appView.loadUrl("file:///android_asset/index.html");
        root.addView(appView, new FrameLayout.LayoutParams(-1,-1));

        brokerView = createBrokerView();
        brokerView.setVisibility(View.GONE);
        root.addView(brokerView, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    private WebView createBrokerView() {
        WebView view = new WebView(this);
        configure(view, false);
        view.setBackgroundColor(Color.WHITE);
        view.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
                brokerPageStarted = true;
                if (brokerVisible) appView.setVisibility(View.GONE);
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (brokerVisible) {
                    v.setVisibility(View.VISIBLE);
                    appView.setVisibility(View.GONE);
                }
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    closeBrokerWithMessage("Không mở được trang sàn. LAM BO vẫn được giữ lại.");
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
            }
            @Override public boolean onRenderProcessGone(WebView v, android.webkit.RenderProcessGoneDetail detail) {
                recoverBrokerView();
                Toast.makeText(MainActivity.this, "Trang sàn gặp lỗi WebView; LAM BO vẫn hoạt động.", Toast.LENGTH_LONG).show();
                return true;
            }
        });
        return view;
    }

    private void configure(WebView view, boolean localApp) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(localApp);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        view.setWebChromeClient(new WebChromeClient());
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true);
    }

    private void openBroker(int index) {
        if (index < 0 || index >= brokerUrls.length) return;
        try {
            brokerVisible = true;
            brokerPageStarted = false;
            brokerView.setVisibility(View.VISIBLE);
            appView.setVisibility(View.VISIBLE);
            String target = brokerUrls[index];
            brokerView.loadUrl(target);
        } catch (Exception e) {
            brokerVisible = false;
            brokerView.setVisibility(View.GONE);
            appView.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Không thể mở trang sàn: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void closeBroker() {
        brokerVisible = false;
        brokerView.stopLoading();
        brokerView.setVisibility(View.GONE);
        appView.setVisibility(View.VISIBLE);
    }

    private void closeBrokerWithMessage(String message) {
        closeBroker();
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void recoverBrokerView() {
        try {
            if (brokerView != null) {
                root.removeView(brokerView);
                brokerView.destroy();
            }
            brokerVisible = false;
            brokerView = createBrokerView();
            brokerView.setVisibility(View.GONE);
            root.addView(brokerView, new FrameLayout.LayoutParams(-1,-1));
            appView.setVisibility(View.VISIBLE);
        } catch (Exception ignored) {
            appView.setVisibility(View.VISIBLE);
            brokerVisible = false;
        }
    }

    private class Bridge {
        @JavascriptInterface public void openBroker(final int index) {
            runOnUiThread(() -> openBroker(index));
        }
        @JavascriptInterface public void closeBroker() {
            runOnUiThread(() -> closeBroker());
        }
    }

    @Override public void onBackPressed() {
        if (brokerVisible) {
            if (brokerView != null && brokerView.canGoBack()) brokerView.goBack(); else closeBroker();
        } else if (appView != null && appView.canGoBack()) {
            appView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override protected void onDestroy() {
        if (appView != null) appView.destroy();
        if (brokerView != null) brokerView.destroy();
        super.onDestroy();
    }
}
